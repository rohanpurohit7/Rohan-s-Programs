package com.Rohan;

import java.util.*;

public class Main {

    private static ArrayList<Album> albums = new ArrayList<Album>();

    public static void main(String[] args) {

        Album album = new Album("MusicAlbum", "RockBand");
        album.addSong("songone", 4.2);
        album.addSong("songtwo", 3.4);
        album.addSong("songthree", 5.6);
        albums.add(album);

        Album album2 = new Album("MusicAlbum2", "Guitarists");
        album2.addSong("guitarpiece", 4.2);
        album2.addSong("pianopiece", 3.4);
        album2.addSong("xylophonepiece", 5.6);
        albums.add(album2);


        LinkedList<Song> playList = new LinkedList<Song>();
      albums.get(0).addToPlaylist("songone", playList);
       albums.get(0).addToPlaylist("songtwo",playList);
        albums.get(0).addToPlaylist("songthree",playList);
        albums.get(1).addToPlaylist("guitarpiece",playList);
       albums.get(1).addToPlayList(1, playList);
        albums.get(1).addToPlayList(2, playList);

        play (playList);


	// write your code here
    }

    private static void play (LinkedList<Song> playList){
        Scanner scanner = new Scanner(System.in);
        boolean quit = false;
        boolean forward = true;

        ListIterator<Song> listIterator = playList.listIterator();
        if(playList.size() == 0){
            System.out.println("No songs in playlist");
            return;
        }else {
            System.out.println("Now Playing" + listIterator.next().toString());
            printMenu();
        }
while (!quit){
            int action = scanner.nextInt();
            scanner.nextLine();

            switch(action){
                case 0:
                    System.out.println("Playlist complete");
                    quit = true;
                    break;
                case 1:
                    if(!forward){
                        if(listIterator.hasNext()){
                            listIterator.next();
                        }
                        forward = true;
                    }
                    if(listIterator.hasNext()){
                        System.out.println("Now playing"+ listIterator.next().toString());
                    }else{
                        System.out.println("We have reached end of the playlist");
                        forward = false;
                    }
                    break;
                case 2:
                    if(forward){
                        if(listIterator.hasPrevious()){
                            listIterator.previous();
                        }forward =false;
                    }
                    if(listIterator.hasPrevious()){
                        System.out.println("Now Playing " + listIterator.previous().toString());
                    }else{
                        System.out.println("We are at start of playlist");
                        forward = true;
                    }
                    break;
                case 3:
                    if(forward){
                        if(listIterator.hasPrevious()){
                            System.out.println("Now replaying"+ listIterator.previous().toString());
                            forward = false;
                        }else {
                            System.out.println("We are at start of list");
                        }
                        }else{
                            if (listIterator.hasNext()){
                                System.out.println("Now replaying" + listIterator.next().toString());
                                forward = true;
                            }else{
                                System.out.println("We have reached the end of the list");
                        }
                    }
                    break;
                case 4:
                    printList(playList);
                    break;
                case 5:
                    printMenu();
                    break;

                case 6:
                    if(playList.size()>0){
                        listIterator.remove();
                        if(listIterator.hasNext()){
                            System.out.println("Now playing"+ listIterator.next());
                        }else if(listIterator.hasPrevious()){
                            System.out.println("Now playing"+ listIterator.previous());
                        }
                    }break;
            }
}

    }

    private static void printMenu(){
        System.out.println("Available actions \n");
        System.out.println("0 - to quit\n");
        System.out.println("1- to play next song\n");
        System.out.println("2- to play previous song\n");
        System.out.println("3- to replay current song \n");
        System.out.println("4- to list songs in the playlist \n");
        System.out.println("5- print available actions\n");
        System.out.println("6- remove song in the playList\n");
    }

    private static void printList(LinkedList<Song> playList){
        Iterator<Song> iterator = playList.iterator();
        System.out.println("===============");
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("================");
    }


}
