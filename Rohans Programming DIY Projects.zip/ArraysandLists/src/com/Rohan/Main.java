package com.Rohan;
import java.util.Scanner;


public class Main {

    private static Scanner s  = new Scanner(System.in);
    private static int [] baseData = new int [10];


    public static void main(String[] args) {
	// write your code here

        //int [] baseData = {1,2,3,4,5,6,7,8,9,10};
        System.out.println("Enter 10 integers");
        getInput();
        printArray(baseData);

        resizeArray(baseData);
        System.out.println("Enter 12 integers");
        getInput();
        printArray(baseData);

    }

    private static void getInput(){
        for(int i =0; i<baseData.length; i++){
            baseData[i]= s.nextInt();
        }
    }


    private static void printArray(int[] array){
        for(int i =0; i<array.length;i++){
            System.out.println("Element "+ i+" has value, "+ array[i] );
        }
    }

    private static void resizeArray (int[] array){
        int[] original = baseData;
        baseData = new int [12];// increase array length by 2
        for(int i = 0; i<original.length; i++)
            baseData[i]= original[i];
    }
}
