import java.util.*;


public class RohanPurohitIntArray implements IntArray {
	
	
	// Current Array Initialization//
	int anarray[]= new int [10];
	int capacity = 10;
	int size = capacity-1;
	int anEntry;
	
	private Node head = null;
	
	 private static class Node {
	        private Object data;
	        private Node next;

	        private Node(Object dataValue) {
	        data = dataValue;
	        	
	        } // end Node

	        private Node(Object dataValue, Node pointer) {
	        	data = dataValue;
	        	next = pointer;
	        } // end Node
	    } // end Node
	 
	
	 /** Return the object located at the specified zero-based index.
    @param index The zero-based index indicating the location
                 of the element to return
    @return A reference to the object located at position index
    @throws IndexOutOfBoundsException if the provided index is not within
                                      the bounds of the array.
*/
public int get(int index){
	System.out.println("index" + index);// print index value
	System.out.println("size" + size);// print size
	if(index<0|| index>= size){
		throw new IndexOutOfBoundsException();// check for out of bounds exception
	}
	return index;// return a reference to the object located at the position index.
}// end get

/** Assign the provided object to the specified zero-based index,
  displacing and return any value already stored in that location.
    @param index The zero-based index indcating the location at which
                 to insert the element
    @param anEntry A reference object to insert
    @return A reference to the object being displaced by anEntry, or null
            if the specified index was unused
    @throws IndexOutOfBoundsException if the provided index is not within
                                      the bounds of the array.
*/
public Object set(int index, Object anEntry){
	Node current = new Node(null);
	current = head;
	for(int i =0;i<index;i++){
		current = current.next;
	}
	Object r = current.data;
	current.data = anEntry;
    return r;

}// end set
/** Return the size of the array.
    @return The size of the array 
*/
public int size(){
	return size;
}
/** Add a reference to the object anEntry at the end of the array,
  increasing the capacity of the array if needed.
    @param anEntry A reference to the object to be inserted
*/
public void add(int anEntry){
System.out.println("Adding"+anEntry);
if(head == null){//Adds to an empty list.
	head = new Node(anEntry);}
	else{
		Node current = head;
		while(current.next!= null){
			current = current.next;}
		current.next = new Node(anEntry);//Inserts at Head.
		}
	size++;
	}// end add method

/** Add a reference to the object anEntry at the specified index, pushing
  existing elements to the right or inserting zeros to make room, and 
  increasing the capacity of the array if necessary.
    @param index The location at which to insert the object
    @param anEntry A reference to the object to be inserted
*/
public void add(int index, int anEntry){}

/** Find the specified object in the array and return its index, or -1
  if the object could be found.
    @param target The object to find in the array
    @return The location of the specified object, or -1 if the array
            does not contain it.
*/
public int indexOf(int target){
	Node current = head;
	int i = 0;
	while(current!=null){
		if(current.data.equals(target))
			return i;
		current = current.next;
		i++;
	}
    return -1;
} // end indexOf


/** Remove and return the object located at the specified index, shifting
  any elements that follow it to the left to fill the vacated space.
    @param index The location of the object to remove
    @return A reference to the object just removed from the array.
    @throws IndexOutOfBoundsException if the provided index is not within
                                      the bounds of the array.
*/
public Object remove(int index){
	if(index<0||index>size-1){
		throw new IllegalArgumentException();// checks the limits of the indexes given to be operated on.
	}
	Node current = head;
	Object removedentry;
	if(index ==0){
		removedentry = head.data;
		head = head.next;
		size--;
		return removedentry;}
	for(int i=0;i<index-1;i++){
		current = current.next;}
	removedentry = current.next.data;
	current.next = current.next.next;
	size--;
	return removedentry;
}// end remove


/** Reduce the capacity of the array to the smallest possible size that will
  still store all of the elements currently contained in it.
  @return true if the capacity was reduced, false otherwise.
*/
public boolean trim(){
	return true;
}
}// end trim
/** Return a string of the format [0 5 3] for the current array contents;
  empty arrays should provide []; single-entry arrays should provide [7].
  @return A string of space-delimited entries from the array, contained in
          square brackets.

public String toString(){// I wasn't sure of this toString method so I commented this section out.
	String output = null;
	while( current.next != null)
	{
	 output = output + current.data;
	current = current.next;
	}
	return output;
}
}
*/
