
public interface IntArray
{
  /** Return the object located at the specified zero-based index.
        @param index The zero-based index indicating the location
                     of the element to return
        @return A reference to the object located at position index
        @throws IndexOutOfBoundsException if the provided index is not within
                                          the bounds of the array.
   */
  public int get(int index)
    throws IndexOutOfBoundsException;

  /** Assign the provided object to the specified zero-based index,
      displacing and return any value already stored in that location.
        @param index The zero-based index indcating the location at which
                     to insert the element
        @param anEntry A reference object to insert
        @return A reference to the object being displaced by anEntry, or null
                if the specified index was unused
        @throws IndexOutOfBoundsException if the provided index is not within
                                          the bounds of the array.
   */
  public Object set(int index, Object anEntry)
    throws IndexOutOfBoundsException;

  /** Return the size of the array.
        @return The size of the array 
   */
  public int size();
  /** Add a reference to the object anEntry at the end of the array,
      increasing the capacity of the array if needed.
        @param anEntry A reference to the object to be inserted
   */
  public void add(int anEntry);

  /** Add a reference to the object anEntry at the specified index, pushing
      existing elements to the right or inserting zeros to make room, and 
      increasing the capacity of the array if necessary.
        @param index The location at which to insert the object
        @param anEntry A reference to the object to be inserted
   */
  public void add(int index, int anEntry);

  /** Find the specified object in the array and return its index, or -1
      if the object could be found.
        @param target The object to find in the array
        @return The location of the specified object, or -1 if the array
                does not contain it.
   */
  public int indexOf(int target);

  /** Remove and return the object located at the specified index, shifting
      any elements that follow it to the left to fill the vacated space.
        @param index The location of the object to remove
        @return A reference to the object just removed from the array.
        @throws IndexOutOfBoundsException if the provided index is not within
                                          the bounds of the array.
   */
  public Object remove(int index)
    throws IndexOutOfBoundsException;

  /** Reduce the capacity of the array to the smallest possible size that will
      still store all of the elements currently contained in it.
      @return true if the capacity was reduced, false otherwise.
   */
  public boolean trim();

  /** Return a string of the format [0 5 3] for the current array contents;
      empty arrays should provide []; single-entry arrays should provide [7].
      @return A string of space-delimited entries from the array, contained in
              square brackets.
   */
  public String toString();
}
