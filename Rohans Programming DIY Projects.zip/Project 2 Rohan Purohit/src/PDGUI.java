
import javax.swing.*;

/** This class is an implementation of PDUserInterface
    that uses JOptionPane to display the menu of command choices.
    @author Koffman & Wolfgang; modified by Torczon
 */
public class PDGUI implements PDUserInterface {

  /** A reference to the PhoneDirectory object to be processed.
        Globally available to the command-processing methods.
   */
  private PhoneDirectory theDirectory = null;

  // Methods
  /** Method to display the command choices and process user
        commands.
        pre:  The directory exists and has been loaded with data.
        post: The directory is updated based on user commands.
        @param thePhoneDirectory A reference to the PhoneDirectory
               to be processed.
   */
  public void processCommands(PhoneDirectory thePhoneDirectory) {

    String[] commands = {
        "Add/Change Entry",
        "Look Up Entry",
        "Remove Entry",
        "Save Directory",
        "Exit"};

    theDirectory = thePhoneDirectory;
    int choice;

    do {
      choice = JOptionPane.showOptionDialog(
          null, // No parent
          "Select a Command", // Prompt message
          "PhoneDirectory", // Window title
          JOptionPane.YES_NO_CANCEL_OPTION, // Option type
          JOptionPane.QUESTION_MESSAGE, // Message type
          null, // Icon
          commands, // List of commands
          commands[commands.length - 1]); // Default choice
      switch (choice) {
        case 0:
          doAddChangeEntry();
          break;
        case 1:
          doLookupEntry();
          break;
        case 2:
          doRemoveEntry();
          break;
        case 3:
          doSave();
          break;
        case 4:
          doSave();
          break;
      } // end switch
    } // end do
    while (choice < commands.length - 1);
    System.exit(0);
  } // end processCommands(PhoneDirectory thePhoneDirectory)

  /** Method to add or change an entry.
        pre:  The directory exists and has been loaded with data.
        post: A new name is added, or the value for the name is
              changed, modified is set to true.
   */
  private void doAddChangeEntry() {
    // Request the name
    String newName = JOptionPane.showInputDialog("Enter name");
    if (newName == null) {
      return; // Dialog was cancelled.
    } // end if
    // Request the number
    String newNumber = JOptionPane.showInputDialog("Enter number");
    if (newNumber == null) {
      return; // Dialog was cancelled.
    } // end if
    // Insert/change name-number
    String oldNumber = theDirectory.addOrChangeEntry(newName,
        newNumber);
    String message = null;
    if (oldNumber == null) { // New entry.
      message = newName + " was added to the directory"
          + "\nNew number: " + newNumber;
    } // end if
    else { // Changed entry.
      message = "Number for " + newName + " was changed "
          + "\nOld number: " + oldNumber
          + "\nNew number: " + newNumber;
    } // end else
    // Display confirmation message.
    JOptionPane.showMessageDialog(null, message);
  } // end doAddChangeEntry()

  /** Method to look up an entry.
        pre:  The directory has been loaded with data.
        post: No changes made to the directory.
   */
  private void doLookupEntry() {
    // Request the name.
    String theName = JOptionPane.showInputDialog("Enter name");
    if (theName == null) {
      return; // Dialog was cancelled.
    } // end if
    // Look up the name.
    String theNumber = theDirectory.lookupEntry(theName);
    String message = null;
    if (theNumber != null) { // Name was found.
      message = "The number for " + theName + " is " + theNumber;
    } // end if
    else { // Name was not found.
      message = theName + " is not listed in the directory";
    } // end else
    // Display the result.
    JOptionPane.showMessageDialog(null, message);
  } // end  doLookupEntry()

  /** Method to remove an entry.
        pre:  The directory has been loaded with data.
        post: The requested name is removed, modified is set to true.
   */
  private void doRemoveEntry() {
    //  Request the name
    String newName = JOptionPane.showInputDialog("Enter name");
    
    if (newName == null) 
    { // Dialog was cancelled.
      return; 
    } // end if
    
    String oldNumber = theDirectory.removeEntry(newName);
    String message = null;
    
    if (oldNumber != null) 
    { // the entry was found and deleted
       message = newName + " was deleted from the directory";
    } // end if
    else 
    { // entry not found
       message = newName + " is not listed in the directory.";
    } // end else
    
    // Display confirmation message.
    JOptionPane.showMessageDialog(null, message);

  } // end doRemoveEntry()

  /** Method to save the directory to the data file.
        pre:  The directory has been loaded with data.
        post: The current contents of the directory have been saved
              to the data file.
   */
  private void doSave() {
    theDirectory.save();
  } // end doSave()
} // end class PDGUI
