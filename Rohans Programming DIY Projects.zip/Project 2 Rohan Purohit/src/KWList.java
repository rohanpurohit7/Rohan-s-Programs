
import java.io.*;

/** This is an implementation of the KWList interface that uses
    an array to store the data.
    @author Koffman & Wolfgang; modified by Noonan
 */

public interface KWList {

    /** Returns the number of entries in <code>list</code>.
     */
    public abstract int size();

    /** Searches for <code>target</code>.
        Returns the index of the first occurrence, if found;
        otherwise returns -1.
    */
    public abstract int indexOf(Object target);

    /** Return a reference to the element at position
    <code>index</code>.
    */
    public abstract Object get(int index);

    /** Set the element at position
    <code>index</code> to <code>anEntry</code>.
    Return the old value.
    */
    public abstract Object set(int index, Object anEntry);

    /** Adds a reference to <code>anEntry</code> at index _c(size) of the
        <code>list</code>; if necessary, the _c(list) is made larger.  
        Always returns <code>true<code>.
    */
    public abstract boolean add(Object anEntry);

    /** Returns and removes the item at position <code>index</code>
        (in the range 0...size-1).
    */
    public abstract Object remove(int index);

} // end class
