import java.io.*;
import java.util.Iterator;

/** This is an implementation of the PhoneDirectory interface that uses
    an array to store the data.
    @author Koffman & Wolfgang; modified by Dutton
 */

public class LinkBasedPD implements PhoneDirectory {

  // Data Fields

  /** The array to contain the directory data */
    private KWLinkedList list = new KWLinkedList( );

  /** The data file that contains the directory data */
  private String sourceName = null;

  /** Boolean flag to indicate whether the directory was
        modified since it was either loaded or saved. */
  private boolean modified = false;

  /** Method to load the data file.
     pre:  The directory storage has been created and it is empty.
           If the file exists, it consists of name-number pairs
           on adjacent lines.
     post: The data from the file is loaded into the directory.
     @param sourceName The name of the data file
   */
   public void loadData(String sourceName) {
    // Remember the source name.
    this.sourceName = sourceName;
    try {
      // Create a BufferedReader for the file.
      BufferedReader in = new BufferedReader(
          new FileReader(sourceName));
      String name;
      String number;
       System.out.println(sourceName);
      // Read each name and number and add the entry to the array.
      while ( (name = in.readLine()) != null) {
        // Read name and number from successive lines.
        if ( (number = in.readLine()) == null) {
          break; // No number read, exit loop.
        } // end if
        // Add an entry for this name and number.
        System.out.println("add");
        list.add(new DirectoryEntry(name, number));
      } // end while
      // Close the file.
      in.close();
    } // end try
    catch (FileNotFoundException ex) {
    	System.out.println("catch 1");
    	
    	
      // Do nothing - no data to load.
      return;
    } // end catch
    catch (IOException ex) {    	
      System.err.println("Load of directory failed.");
      ex.printStackTrace();
      System.exit(1);
    } // end catch
  } // end loadData(String sourceName)

  /** Add an entry or change an existing entry.
    @param name The name of the person being added or changed
    @param number The new number to be assigned
    @return The old number or, if a new entry, null
   */
  public String addOrChangeEntry(String name, String number) {
    String oldNumber = null;
    int index = list.indexOf(new DirectoryEntry(name, ""));
    if (index > -1) {
        DirectoryEntry entry =
            (DirectoryEntry)(list.set(index,
                                      new DirectoryEntry(name, number)));
      oldNumber = entry.getNumber();
    } // end if
    else {
        list.add(new DirectoryEntry(name, number));
    } // end else
    modified = true;
    return oldNumber;
  } // end addOrChangeEntry(String name, String number)

  /** Look up an entry.
      @param name The name of the person
      @return The number. If not in the directory, null is returned
   */
  public String lookupEntry(String name) {
    int index = list.indexOf(new DirectoryEntry(name, ""));
    if (index > -1) {
        return ((DirectoryEntry)list.get(index)).getNumber();
    } // end if
    else {
      return null;
    } // end else
  } // end lookupEntry(String name)

  /** Remove an entry from the directory.
          @param name The name of the person to be removed
          @return The current number. If not in directory, null is
          returned
   */
  public String removeEntry(String name) {
    int index = list.indexOf(new DirectoryEntry(name, ""));
    if (index > -1) {
        return ((DirectoryEntry)list.remove(index)).getNumber();
    } // end if
    else {
      return null;
    } // end else
  } // end removeEntry(String name)

  /** Method to save the directory.
      pre:  The directory has been loaded with data.
      post: Contents of directory written back to the file in the
            form of name-number pairs on adjacent lines.
            modified is reset to false.
   */
  public void save() {
      modified = false;
      for (Iterator i = list.iterator(); i.hasNext(); ) {
          System.out.println(i.next());
      }
      //for(int i = 0; i<list.size(); i++){
      //    System.out.println("Element " + i+ ": " + list.get(i));
      //}
  } // end save()

  /** Add an entry to the directory.
      @param name The name of the new person
      @param number The number of the new person
   */
  private void add(String name, String number) {
      list.add(new DirectoryEntry(name, number));
  } // end add(String name, String number)

} // end class ArrayBasedPD
