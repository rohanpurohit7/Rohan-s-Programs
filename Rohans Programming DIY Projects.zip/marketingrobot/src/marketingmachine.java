
public class marketingmachine {
public static void main(String[] args){
	// fancy words 
	String[] suckupOne = {"prodigious", "powerful","targeted","accelerated","mindblowing"};
	String[] suckupTwo = {"b2b", "enterprise","technological","hadoop","scaling"};
	String[] suckupThree = {"solutions", "strategies","tactics","techniques","marketing drives"};
	
// length computation
int oneLength = suckupOne.length;
int twoLength = suckupTwo.length;
int threeLength = suckupThree.length;

//random number generation
int rand1= (int) (Math.random() * oneLength);
int rand2= (int) (Math.random() * twoLength);
int rand3= (int) (Math.random() * threeLength);

//advisor quote
String phrase = suckupOne[rand1] + " " + suckupTwo[rand2]+" "+ suckupThree[rand3];

// print out expertise

System.out.println("Advice from marketing machine: What we need here are a host of " + phrase);
}
}


