package com.Rohan;

/**
 * Created by Rohan on 1/20/2017.
 */



    public class sortletters {
        public String[] sort(String[] asd) {
            String[] sorted = asd.clone();
            for (int i = 0; i < sorted.length; i++) {
                for (int j = i + 1; j < sorted.length; j++) {
                    int compare = sorted[i].compareTo(sorted[j]);
                    if ((compare > 0) && (i != j)) {
                        //compare two strings
                        String temp = sorted[j];
                        sorted[j] = sorted[i];
                        sorted[i] = temp;
                    }
                }
            }
            return sorted;
        }

    }
