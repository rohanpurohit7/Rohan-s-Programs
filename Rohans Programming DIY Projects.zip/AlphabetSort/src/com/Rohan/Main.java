package com.Rohan;

import java.util.Scanner;

public class Main{

    public static void main(String[] args) {
        sortletters list1 = new sortletters();
        //SortLetters is the class name
        Scanner scan1 = new Scanner(System.in);
        String wd1, wd2, wd3, wd4;
        System.out.println("Type Word One: ");
        wd1 = scan1.next();
        System.out.println("Type Word Two: ");
        wd2 = scan1.next();
        System.out.println("Type Word Three: ");
        wd3 = scan1.next();
        System.out.println("Type Word Four: ");
        wd4 = scan1.next();
        String array[] = {wd1, wd2, wd3, wd4};
        //set array equal to the inputs
        String[] sortedArray = list1.sort(array);
        for (int i = 0; i < sortedArray.length; i++) {
            if (i == sortedArray.length - 1) {
                System.out.println(sortedArray[i]);
            } else {
                System.out.print(sortedArray[i] + ",");
            }}}}

        //run sorting progra