package com.Rohan;
public class Main {

    public static void main(String[] args) {

//        GamePlayer player = new GamePlayer();
//        player.name = "Rohan";
//        player.health = 100;
//        player.weapon = "sword";
//
//        player.loseHealth(10);
//        player.healthRemaining();

//        EnhancedGamePlayer rohan = new EnhancedGamePlayer("Rohan", 100, "sword");
//        System.out.println("Initial health is " + rohan.getHealth());
//        rohan.loseHealth(10);
//        rohan.getHealth();

        Printer epson = new Printer(100,  true);
        epson.printPage(100);
        epson.printPage(100);
        epson.getTonerPercent();
        epson.printPage(1000);
        epson.getTonerPercent();
        epson.fillUpToner(50);

	// write your code here
    }
}
