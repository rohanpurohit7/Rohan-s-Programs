import java.util.*;
public class sortobject {

	LinkedList<object> obj = new LinkedList<object> ();
	class NameCompare implements Comparator<object>{
		public int compare(object one, object two){
			return one.name.compareTo(two.name);
		}
	}
	class NumberCompare implements Comparator<object>{
		public int compare(object one, object two){
			return(two.number - one.number);
		}
	}
	public static void main(String[]args){
		new sortobject().go();
	}
	public void go(){
		obj.add(new object("R" , 15352));
		obj.add(new object("O" , 15486));
		obj.add(new object("H" , 15848));
		obj.add(new object("A" , 14858));
		obj.add(new object("N" , 18883));
		
		System.out.println("as entered:\n" +obj);
		NameCompare nc = new NameCompare();
		Collections.sort(obj,nc);
		System.out.println("sorted alphabetically by name: \n" + obj);
		NumberCompare numc = new NumberCompare();
		Collections.sort(obj,numc);
		System.out.println("sorted by number in descending order: \n" + obj);
	}
}
