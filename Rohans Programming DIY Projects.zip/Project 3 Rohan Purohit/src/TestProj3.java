import java.util.*;

import javax.swing.JOptionPane;

public class TestProj3 {
	
	public static void main(String[] args){

		
		KWLinkedList expressionevaluator = new KWLinkedList();// Creates a new expressionevaluator object.
		
		expressionevaluator.add("Bugs Bunny");
		expressionevaluator.add("Daffy Duck");
		expressionevaluator.getFirst();
		
		
	if((expressionevaluator).getFirst() == "Bugs Bunny"){// Tests the getFirst method.
			System.out.println("The getFirst method works.");
		}
		else{
			System.out.println("The getFirst method does not work.");}

	
	
	expressionevaluator.removeFirst();// removes Bugs Bunny as the first element and now Daffy Duck is the first element.
	
	

	if((expressionevaluator).getFirst() == "Daffy Duck"){// Tests the removeFirst method.
		System.out.println("The removeFirst method works.");
	}
	else{
		System.out.println("The removeFirst method does not work.");
	}
	
	
	expressionevaluator.addFirst("Tom and Jerry");
	
	if((expressionevaluator).getFirst() == "Tom and Jerry"){// Tests the addFirst method.
		System.out.println("The addFirst method works.");
	}
	else{
		System.out.println("The addFirst method does not work.");}
	}
	
	//-----The new methods for KWLinkedList are tested above( i.e : getFirst, addFirst, removeFirst)---------//
	
	
	//----The expression evaluators are tested below  when I match some pre computed values to my program results---//
	
	InfixToPostfixParens inToPost = new InfixToPostfixParens();{// new InfixToPostfixParens initialized.
	try {
		String str = inToPost.convert("3 + 3 ");
	} catch (InfixToPostfixParens.SyntaxErrorException e) {// a try-catch block to deal with input errors.
		// TODO Auto-generated catch block
		System.out.print(e.getMessage());
		e.printStackTrace();
	}
		
	}
	}//do the translation
	
		


