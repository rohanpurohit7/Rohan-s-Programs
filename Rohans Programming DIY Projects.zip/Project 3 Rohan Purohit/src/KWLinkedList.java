import java.util.NoSuchElementException;
/**
 * This class defines methods for traversing a linked list as well as adding or
 * removing to its members.
 * 
 * @author 
 * ROHAN PUROHIT CS 241 Data Structures Project 2
 *  
 *  PS- During the running of the program I talked with the consultants and we found that my program
 *  works fine with the command line system but when I use the GUI, the list is not printed
 *  They told me that its a eclipse problem and so I need not change anything.
 */
public class KWLinkedList implements KWList {

    // the current size of the linked list
    private int size = 0;

    // the first object in the list
    private Node head = null;

    //OPTIONAL -- you may use a tail pointer in your implementation
    // This may simplify your add() method but can add additional work to
    // to some other method(s).
    //the last object in the list
     /*  private Node tail = null;
     */

    /** Defines the Node for the linked list */
    private static class Node {
        private Object data;

        private Node next;

        private Node(Object dataItem) {
        	data = dataItem;
        	
        } // end Node

        private Node(Object dataItem, Node nodeRef) {
        	data = dataItem;
        	next = nodeRef;
        	
        } // end Node
        public Object getData(){
        	return data;
        }
        	
       
    } // end Node

    /**
     * Gets the current size of the KWLinkedList.
     * 
     * @return integer the size of the linked list
     */
    public int size() {
        return size;
    } // end size

    /**
     * Searches for target and returns the position
     * of the first occurrence (in
     * the range 0...size-1), or -1 if it is not in the KWLinkedList.
     * 
     * @param target
     *            the object to be found
     * @return integer the index location of the desired item in the list
     */
    public int indexOf(Object target) {
    	Node current = head;
    	int i = 0;
    	while(current!=null){
    		if(current.data.equals(target))
    			return i;
    		current = current.next;
    		i++;
    	}
        return -1;
    } // end indexOf

    /**
     * Returns a reference to the element at position index.
     * 
     * @param index
     *            the position of the item desired
     * @return object the data in the position chosen
     */
    public Object get(int index) {
    	System.out.println("index" + index);
    	System.out.println("size" + size);
    	if(index<0|| index>= size){
    		throw new IllegalArgumentException();
    	}
    	Node current= new Node(null);
    	current = head;
    	for(int i=0;i<index;i++){
    		current = current.next;
    	}
        return current.data;
    } // end get

    /** Set the element at position
     *   <code>index</code> to <code>anEntry</code>.
     * Return the old value.
     */ 
    public Object set(int index, Object anEntry) {
    	Node current = new Node(null);
    	current = head;
    	for(int i =0;i<index;i++){
    		current = current.next;
    	}
    	Object r = current.data;
    	current.data = anEntry;
        return r;
    }// end set

    /**
     * Adds a reference to anEntry at the END of the KWLinkedList. 
     * Always returns true.
     * 
     * @param anEntry
     *            the object to be added to the list
     * @return boolean always returns true
     */
    public boolean add(Object anEntry) {
    	System.out.println("Adding"+anEntry);
    	if(head == null){//Adds to an empty list.
    		head = new Node(anEntry);}
    		else{
    			Node current = head;
    			while(current.next!= null){
    				current = current.next;}
    			current.next = new Node(anEntry);//Inserts at Head.
    			}
    		size++;
    		return true;
    		}// end add method
    	
    /**
     * Returns and removes the item at position index
     * (in the range 0...size-1)
     * 
     * @param index
     *            the position of the item to be removed
     * @return object the data contained in the item removed from the list
     */
    public Object remove(int index) {
    	if(index<0||index>size-1){
    		throw new IllegalArgumentException();// Illegal Argument exception thrown after bounds checking.
    	}
    	Node current = head;
    	Object removedentry;
    	if(index ==0){
    		removedentry = head.data;
    		head = head.next;
    		size--;
    		return removedentry;}
    	for(int i=0;i<index-1;i++){
    		current = current.next;}
    	removedentry = current.next.data;
    	current.next = current.next.next;
    	size--;
    	return removedentry;
    	} // end remove
    /**
     * @param n1
     */
    public void addFirst(Object n1) {
    	Node n2 = new Node(n1);
        n2.next = head;
        head = n2;
        size ++;
        return;
      
             }
    
    /**
     * 
     */
    public Object getFirst() {
       
        if(head == null){
    		throw new NoSuchElementException();
    } 
        return head.data;
        }
/**
* 
*/
    public Object removeFirst( ){
    	if(head == null){
    		throw new NoSuchElementException();
    } 
    	Object temp = head.data;	
    head = head.next;	
    size --;
    return temp;
    	
    }
    /** Return an Iterator to the list
        @return an Iterator to the list
    */
    public java.util.Iterator iterator() {
        return new KWListIter( );
    }

    /** Inner class to implement the Iterator interface */
    private class KWListIter implements java.util.Iterator {
        /** A reference to the current item */
        private Node current = head;

        /** Indicate whether not at end of list
            @return true if not at end of list
        */
        public boolean hasNext() {
        	if(current!= null)
        		return true;
        	else
            return false;
        }

        /** Return the current item and move the iterator forward
            @return the current item in the list
            @throws NoSuchElementException if there is no such object
        */
        public Object next() {
        	if(current!=null){
        		Object k = current.data;
        		current = current.next;
        		return k;}
        	else
        		throw new NoSuchElementException();
        	}
    
      
        /**
         * 
         */
        public String toString(){
        
        	String output = null;
        	while( current.next != null)
        	{
        	 output = output + current.data;
        	current = current.next;
        	}
        	return output;
        }
        /** Not to be implemented
         */
        public void remove( ) {
            throw new UnsupportedOperationException( );
        }
    }



    }// end KWListIter
// end KWLinkedList
