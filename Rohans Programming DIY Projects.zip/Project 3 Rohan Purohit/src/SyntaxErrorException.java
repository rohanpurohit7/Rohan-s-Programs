/** SyntaxErrorException is thrown whenever a syntax error occurs while
    converting or evaluating an expression.
    Note: This is an **unchecked** exception.
    @author Torczon, modified Dutton
 */
public class SyntaxErrorException extends RuntimeException {
  
  /** Constructs a new SyntaxErrorException with null
      as its error message string. 
  */
  public SyntaxErrorException() {
      super();
  } // end SyntaxErrorException()

  /** Constructs a new SyntaxErrorException with the
      string s as its error message. 
      @param message String to send as error message
  */
  public SyntaxErrorException(String message) {
      super(message);
  } // end SyntaxErrorException()

} // end class SyntaxErrorException
