
public class TestProj5 {
	public static void main(String[]args){
		BinarySearchTree a = new BinarySearchTree();
	a.add(2);
	a.add(3);
	a.add(4);
	a.add(5);
	a.add(6);
	System.out.println("The binary search tree a is printed as follows-->");
	System.out.println(a.toString());// Testing toString method
	
	// Testing the size method
	if(a.size()==5)
		System.out.println("The size method works correctly");
			
	
	// Testing the contains method.
	if(a.contains(5)== true)
		System.out.println("The contains method works correctly");
	
	//Testing the remove method.
	a.remove(6);// The entry 6 removed from the tree
	
	if(a.contains(6)== false)
		System.out.println("The remove method successfully removed the entry 6.");
	
	// Testing the BinarySearchTree constructor.
	
	BinarySearchTree b = new BinarySearchTree(7, new BinarySearchTree(8,null,null), new BinarySearchTree(9,null, null));
	System.out.println("The binary tree b is printed as follows-->  ");
	System.out.println(b.toString());// prints out the Binary Search Tree b.
	
// Testing breadthFirstString method.
	System.out.println("The breadthFirstString prints out in level order the tree b-->");
	System.out.println(b.breadthFirstString());// prints out the breadthFirstString of tree b in the specified format.
	
	
	}

}// end testproj5
