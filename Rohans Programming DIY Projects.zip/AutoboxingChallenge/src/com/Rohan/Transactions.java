package com.Rohan;

import java.util.ArrayList;

/**
 * Created by Rohan on 12/22/2016.
 */
public class Transactions {

    private double amount;
    private String transactionid ;
    private ArrayList<Double> myTransactions = new ArrayList();


    Customers newCustomer = new Customers( "Rohan",myTransactions );

    public Transactions(double amount, String transactionid) {
        this.amount = amount;
        this.transactionid = transactionid;
    }

   private void getTransactionsforCustomer(String name ) {
        if(name == newCustomer.getName()){
            printLedger(myTransactions);
        }

//       for (int i =0; i<myTransactions.size();i++){
//           double value =  myDoubleArray.get(i); // unboxing - short format gets double value of
//           System.out.println(i + "-->"+  value);

   }

   private void printLedger(ArrayList myTransactions){
        for (int i =0; i<myTransactions.size(); i++){
       System.out.println("The ledger is as follows:" + "\n" + i +" has value of "+ myTransactions.toString()  );
   }
    }

//    public void addTransactiontoCustomerLedger(double deposit ){
//        myTransactions.add(deposit);
//    }

}

