package com.Rohan;

import java.util.ArrayList;

public class Main {


    public static void main(String[] args) {


        ArrayList<Double> myTransactions = new ArrayList<>();
        ArrayList<Double> myTransactions2 = new ArrayList<>();
        ArrayList<Double> myTransactions3 = new ArrayList<>();
        ArrayList<Customers> myCustomers = new ArrayList<>();
        ArrayList<Branch> myBank = new ArrayList<>();


        Bank thisBank = new Bank(myBank);
        Branch myBranch = new Branch("Centreville Branch",myCustomers);
        myBank.add(myBranch);
        Branch secondBranch = new Branch("Fairfax Branch",myCustomers);
        myBank.add(secondBranch);



        Customers newCustomer = new Customers( "Rohan",myTransactions );
        Customers secondnewCustomer = new Customers("Bushi", myTransactions3);
        myCustomers.add(newCustomer);
        myCustomers.add(secondnewCustomer);

        myTransactions.add(100.00);
        myTransactions.add(100.00);
        myTransactions.add(100.00);

        newCustomer.addTransactiontoCustomerLedger( 600.00);
        newCustomer.printLedger(myTransactions);
        newCustomer.getTransactionDetails(4);

        secondnewCustomer.addTransactiontoCustomerLedger(1000.00);
        secondnewCustomer.printLedger(myTransactions3);




        Customers secondCustomer = new Customers("Bruce", myTransactions2);
        myCustomers.add(secondCustomer);
        myTransactions2.add(300.00);
        secondCustomer.addTransactiontoCustomerLedger(500.00);
        secondCustomer.printLedger(myTransactions2);


        myBranch.getCustomers();
        thisBank.getBranches();



	// write your code here
    }
}
