package com.Rohan;

import java.util.ArrayList;

/**
 * Created by Rohan on 12/22/2016.
 */
public class Customers {

    private String name;
    private ArrayList<Double> myTransactions = new ArrayList();
    private ArrayList<Customers> myCustomers = new ArrayList();
    private double myDeposits;

   // Transactions ledger = new Transactions(amount, name );

    public Customers(String name, ArrayList<Double> myTransactions) {
        this.name = name;
        this.myTransactions = myTransactions;
    }



    public String getName() {
        System.out.println("The name of the account holder is : " + name);
        return name;
    }

    public ArrayList<Double> getMyTransactions() {
        System.out.println(myTransactions.toString());
        return myTransactions;
    }

//    public  Customers addDeposit(String name, double transaction) {
//
//        this.name = name;
//        Customers branchcustomer = new Customers(this.name, myTransactions);
//        myTransactions.add(transaction);
//        return branchcustomer;
//    }


    public void addTransactiontoCustomerLedger(double deposit ){
        myTransactions.add(deposit);
    }

    public void getTransactionDetails(int transactionid) {
        {
            System.out.println("The transaction record is as follows:" + "\n transaction " + (transactionid ) + " has value of " + myTransactions.get(transactionid-1).toString());
        }
    }

    public void printLedger(ArrayList myTransactions){
        for (int i =0; i<myTransactions.size(); i++){
            System.out.println("The ledger is as follows:" + "\n Transaction " + (i+1) +" has value of "+ myTransactions.get(i).toString());
        }
    }


}
