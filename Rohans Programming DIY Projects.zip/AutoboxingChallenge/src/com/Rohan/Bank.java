package com.Rohan;

import java.util.ArrayList;

/**
 * Created by Rohan on 12/22/2016.
 */
public class Bank {

    private ArrayList<Branch> myBank = new ArrayList();
    private ArrayList<Customers> myBranch = new ArrayList();


    public Bank(ArrayList<Branch> myBank) {
        this.myBank = myBank;
    }

    public ArrayList<Branch> getMyBank() {
        return myBank;
    }

    public void setMyBank(ArrayList<Branch> myBank) {
        this.myBank = myBank;
    }

    public void  getBranches() {
        for (int i = 0; i < myBank.size(); i++) {
           String branchList=  myBank.get(i).getName().toString();
            System.out.println("The bank has following branches"+ branchList);
        }

    }}


