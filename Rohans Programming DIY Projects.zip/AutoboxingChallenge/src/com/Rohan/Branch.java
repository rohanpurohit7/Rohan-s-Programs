package com.Rohan;

import java.util.ArrayList;

/**
 * Created by Rohan on 12/22/2016.
 */
public class Branch {
    public String name;
    private ArrayList<Customers> myBranch = new ArrayList();
    private ArrayList<Double> myTransactions = new ArrayList<>();

    public Branch(String name, ArrayList<Customers> myBranch) {
        this.name = name;
        this.myBranch = myBranch;
    }

    public Branch(String name, double initialDeposit){
        this.name = name;
        Customers branchcustomer = new Customers(this.name, myTransactions);
        myTransactions.add(initialDeposit);
        if(branchcustomer.getName() == this.name){
            addDeposit(name,initialDeposit);
            System.out.println("We have an existing account for the customer "+ this.name + "\nDeposited $"+initialDeposit+"into"+ this.name+ "'s account.");
        }
    }



    public  Customers addDeposit(String name, double transaction) {

        this.name = name;
        Customers branchcustomer = new Customers(this.name, myTransactions);
        myTransactions.add(transaction);
        return branchcustomer;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Customers> getMyBranch() {
        return myBranch;
    }

    public ArrayList<Double> getMyTransactions() {
        return myTransactions;
    }


    public void  getCustomers() {
        for (int i = 0; i < myBranch.size(); i++) {
            String customerList = myBranch.get(i).getName().toString();
            System.out.println("The branch has following customers " + customerList);
        }
    }}
