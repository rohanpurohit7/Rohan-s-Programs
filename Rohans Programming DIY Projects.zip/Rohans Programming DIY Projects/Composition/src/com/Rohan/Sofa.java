package com.Rohan;

/**
 * Created by Rohan on 12/19/2016.
 */
public class Sofa {

    private String cushion;
    private int pieces;

    public Sofa(String cushion, int pieces) {
        this.cushion = cushion;
        this.pieces = pieces;
    }

}
