package com.Rohan;

/**
 * Created by Rohan on 12/19/2016.
 */
public class Table {

    private String size;
    private String color;
    private String wood;

    public Table(String size, String color, String wood) {
        this.size = size;
        this.color = color;
        this.wood = wood;
    }


    public void setTable(){
        placeObjects("Dinner", 10, 10);
    }

    private void placeObjects(String object, int x , int y){
        System.out.println("Object "+ object +" placed at " + x+" and "+y);
            }

    public String getSize() {
        return size;
    }

    public String getColor() {
        return color;
    }

    public String getWood() {
        return wood;
    }
}
