package com.Rohan;

/**
 * Created by Rohan on 12/19/2016.
 */
public class Room {

    private int sqft;
    private String name;
    private Table diningTable;
    private Sofa sofa;

    public Room(int sqft, String name, Table diningTable, Sofa sofa) {
        this.sqft = sqft;
        this.name = name;
        this.diningTable = diningTable;
        this.sofa = sofa;
    }

    public int getSqft() {
        return sqft;
    }

    public String getName() {
        return name;
    }

    public Table getDiningTable() {
        System.out.println("Dining table is made of oak ");
        return diningTable;
    }

    public Sofa getSofa() {
        return sofa;
    }
}
