package com.Rohan;

/**
 * Created by Rohan on 1/4/2017.
 */
public class FootballPlayer extends Player{

    public FootballPlayer(String name) {
        super(name);
    }
}
