
/** Program to display and modify a simple phone directory.
 * @author Koffman & Wolfgang; modified by Torczon
 */

public class PDGuiApplication {

  public static void main(String args[]) {
    // Check to see that there is a command line argument.
    if (args.length == 0) {
      System.err.println("You must provide the name of the file"
                         + " that contains the phone directory.");
      System.exit(1);
    } // end if

    // Create a PhoneDirectory object.
    PhoneDirectory phoneDirectory = new LinkBasedPD();
    // Load the phone directory from the file.
    phoneDirectory.loadData(args[0]);
   
    // Create a PDUserInterface object.
    PDUserInterface phoneDirectoryInterface = new PDGUI();
    // Process user commands.
    phoneDirectoryInterface.processCommands(phoneDirectory);
  } // end main

} // end class PDGuiApplication
