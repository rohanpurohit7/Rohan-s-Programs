import java.util.*;

public class TestProj2 {

	public static void main(String[] args){
		KWLinkedList phoneDirectory = new KWLinkedList();// Creates a new phoneDirectory object.

		phoneDirectory.add("Captain Planet");// Adds an element to the beginning of the list.
		phoneDirectory.indexOf("Captain Planet");// Should get the beginning index. 
		System.out.println(phoneDirectory.indexOf("Captain Planet"));// Expected return value =0.

		//Tests the add and indexOf methods	     
		// Since, we add to the beginning of the list the insertion of "Captain Planet"
		// And the subsequent println depicting the 'O' index value of the insertion
		//verifies that the list beginning has changed.

		if(phoneDirectory.indexOf("Captain Planet") == 0){
			System.out.println("The add and the indexOf method are working.");
		}
		else{
			System.out.println("The add and the indexOf methods contain faults.");}

		// Tests the size of the list by calling on the method and printing out the size.
		System.out.println(phoneDirectory.size());

		if(phoneDirectory.size() == 1){
			System.out.println("The size method gives back the expected value of 1");}
		else{
			System.out.println("The size method doesnt work.");}


		// Tests the get and set methods by getting the value at 0("Captain Planet")

		System.out.println(phoneDirectory.get(0));//Should print out string "Captain Planet

		if((phoneDirectory.get(0)) == "Captain Planet"){// Tests the get method.
			System.out.println("The get method works.");
		}
		else{
			System.out.println("The get method does not work.");}

		phoneDirectory.set(0, "Superman");// Tests the Set method.

		if((phoneDirectory.get(0))== "Superman"){
			System.out.println("The set method worked and the value has been changed");
		}
		else{
			System.out.println("The set method does not work correctly.");}

		// Tests the remove   
		phoneDirectory.add("Spiderman");
		phoneDirectory.add("Batman");
		phoneDirectory.add("Joker");
		phoneDirectory.add("Green Goblin");

		phoneDirectory.remove(0);
		System.out.println(phoneDirectory.get(0));

		if((phoneDirectory.get(0)== "Spiderman")){
			System.out.println("The remove method works as Superman was removed from the beginning of the list.");
		}else{
			System.out.println("The remove method has faults.");}

		//Testing to see if the list is robust via the middle and the last elements.
		System.out.println(phoneDirectory.get(2));

		if((phoneDirectory.get(2)== "Joker")){
			System.out.println("The list's middle element can be accessed. The pointers are working.");
		}
		else
			System.out.println("The list's middle elements cannot be accessed, there is a problem.");

		System.out.println(phoneDirectory.get(3));

		if((phoneDirectory.get(3)== "Green Goblin")){
			System.out.println("The list's last element can be acessed.The pointers are working.");}
		else{
			System.out.println("The lists last element cannot be accessed, tehre is a problem.");
		}
	}//end main

}// end class TestProj 2

