/**
 * The DirectoryEntry objects will contain name-and-number pairs. The name is
 * immutable; that is, it cannot be changed. The concept for this class was
 * taken from Objects, Abstractions, Data Structures and Design Using Java by
 * Koffman and Wolfgang.
 * Modified by: Dutton 
 */
public class DirectoryEntry {

    /** The name of the individual represented in the entry */
    private String name;

    /** The phone number of the individual represented in the entry */
    private String number;

    /** This method creates a new DirectoryEntry object with the
     * specified name and number 
     @param name The name of the person 
     @param number The number to be assigned to that person
    */
    public DirectoryEntry(String name, String number) {
	this.name = name;
	this.number = number;

    } // end DirectoryEntry Method

    /** This method returns the name of the entry
	@return the name of the entry
    */
    public String getName() {
	return name;
    } // end getName method

    /** This method returns the phone number of the entry
	@return the phone number of the entry
    */
    public String getNumber() {
	return number;
    } // end getNumber method

    /** This method changes the number of an entry
	@param number the new number to be assigned to the entry
    */
    public void setNumber(String number) {
	this.number = number;
    } // end setNumber method

    /** Tests if two DirectoryEntry objects have same name.
	@param obj  test this equals obj
	@return if two objects are equal
    */
    public boolean equals(Object obj) {
	if(this == obj) return true;
        if(obj == null) return false;
        if(!getClass().equals(obj.getClass())) return false;

        DirectoryEntry de = (DirectoryEntry) obj;
        return name.equalsIgnoreCase(de.name);
        
    }

    /** return a string representing the object
	@return  a string representation of the object
    */
    public String toString( ) {
	return "Name: " + name + "\nNumber: " + number + "\n";
    }

} // end class DirectoryEntry
