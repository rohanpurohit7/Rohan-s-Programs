import java.io.*;

/** Class for a binary tree that stores Object objects.
 *  @author Koffman and Wolfgang; modified by Torczon, Dutton
 * */

public class BinaryTree implements Serializable {

    /** Class to encapsulate a tree node. */
    protected static class Node implements Serializable {
        
        // Data Fields
        /** The information stored in this node. */
        protected Object data;
        
        /** Reference to the left child. */
        protected Node left = null;
        
        /** Reference to the right child. */
        protected Node right = null;

        // Constructors
        /** Construct a node with given data and no children.
            @param data The data to store in this node
        */
        public Node(Object data) {
            this.data = data;
         } // end Node(Object data)

        // Methods
        /** Return a string representation of the node.
            @return A string representation of the data fields
        */
        public String toString() {
            return data.toString();
        } // end toString()
    } // end class Node

    // Data Field
    /** The root of the binary tree */
    protected Node root = null;

    public BinaryTree() {
        this(null);
    } // end BinaryTree()

    protected BinaryTree(Node root) {
        this.root = root;
    } // end BinaryTree(Node root)

    /** Constructs a new binary tree with data in its root,
        leftTree as its left subtree and rightTree as its
        right subtree.  Makes a **deep copy** of both leftTree
        and rightTree.
    */
    public BinaryTree(Object data, BinaryTree leftTree,
                      BinaryTree rightTree) {

    	root = new Node (data);// done via pg  412 in text
    	if(leftTree != null){
    		root.left = copyTree(leftTree.root);
    	}else{
    		root.left = null;
    	}
    	if(rightTree != null){
    		root.right= copyTree(rightTree.root);
    	}else{
    		root.right = null;
    	}
    	//root = copyTree(root);

    } // end BinaryTree(Object data, ...)


    /** Returns a reference to a new binary tree containing a deep
        copy of the binary tree rooted at the specified node.
    */
    private Node copyTree(Node originalTreeRoot) {
    	
    	if(originalTreeRoot != null){
    	Node root = new Node(originalTreeRoot.data);
        root.left = copyTree(originalTreeRoot.left);
    	root.right = copyTree(originalTreeRoot.right);
    	return root;}
    	else{
    		return null;
    	}
    	
           
    } // end copyTree

    /** Return the left subtree.
        @return The left subtree or
        null if either the root or the
        left subtree is null
    */
    public BinaryTree getLeftSubtree() {
        if (root == null)
            return null;
        return new BinaryTree(root.left);
    } // end getLeftSubtree()

    /** Return the right sub-tree
        @return the right sub-tree or
        null if either the root or the
        right subtree is null.
    */
    public BinaryTree getRightSubtree() {
        if (root == null)
            return null;
        return new BinaryTree(root.right);
    } // end getRightSubtree

    /** Determine whether this tree is a leaf.
        @return true if the root has no children
    */
    public boolean isLeaf() {
        return (root.left == null && root.right == null);
    } // end isLeaf()

    public int size() {
return sizeRec (this.root);
        } // end size()

    private int sizeRec( Node node){
    if(node == null)
    	return 0;
    else 
    	return 1+ Math.max(sizeRec(node.right), sizeRec(node.left));}
    
   
    public int height(){
    	return height(root);
     }

    protected int height(Node localRoot){
    	// Algorithm for computing tree height
    	//* If T is empty, its height is 0.
        //* If T is not empty, its height is
        //1 + max{the height of TL, the height of TR}.
    	if(root == null){
    		int height = 0;}
    	else{
    			return 1 + Math.max(height(localRoot.left),height(localRoot.right));
    		}
    	return -1;
    	}

     
    public String toString() {
        StringBuffer sb = new StringBuffer();
        preOrderTraverse(root, 1, sb);
        return sb.toString();
    } // end toString()

    /** Perform a preorder traversal.
        @param node The local root
        @param depth The depth
        @param sb The string buffer to save the output
    */
    private void preOrderTraverse(Node node, int depth,
                                  StringBuffer sb) {
        for (int i = 1; i < depth; i++) {
            sb.append("  ");
        } // end for
        if (node == null) {
            sb.append("null\n");
        }  // end if
        else {
            sb.append(node.toString());
            sb.append("\n");
            preOrderTraverse(node.left, depth + 1, sb);
            preOrderTraverse(node.right, depth + 1, sb);
        } // end else
    } // end preOrderTraverse(Node node, ...)


    public String breadthFirstString() {
    	ArrayQueue q = new ArrayQueue();
    	StringBuffer sb = new StringBuffer();
    	q.offer(root);
    	Node temp = root;
    	Node comp = root;
    	boolean next = true;
    	while(!q.isEmpty()){
    		temp=(Node)q.remove();
    		if((temp.data).equals(comp.data)){
    			sb.append("\n" + temp.data + " ");
    			next = false;
    		}
    		else
    			sb.append(temp +"");
    		if(temp.left!=null){
    			q.offer(temp.left);
    			if(!next){
    				comp = temp.left;
    			 next = true;
    			}
    		}
    			if(temp.right!=null){
        			q.offer(temp.right);
        			if(!next){
        				comp = temp.right;
        			} next = true;
    			}
    		}
    	sb.append("\n");
    	return sb.toString();
		
    	}
    	

        // Implementation left as a project.
      
   // end levelOrderString()

    /** Method to read a binary tree.
        pre: The input consists of a preorder traversal
        of the binary tree. The line "null" indicates a null tree.
        @param bR The input file
        @return The binary tree
        @throws IOException If there is an input error
    */
    public static BinaryTree readBinaryTree(BufferedReader bR)
        throws IOException {
        // Read a line and trim leading and trailing spaces.
        String data = bR.readLine();
        if (data == null)
            return null;
        data = data.trim( );
        if (data.equals("null"))
            return null;
        BinaryTree left = readBinaryTree(bR);
        BinaryTree right = readBinaryTree(bR);
        return new BinaryTree(data, left, right);
    } // end readBinaryTree(BufferedReader bR)

    
    /** Return the data field of the root
        @return the data field of the root
        or null if the root is null
    */
    public Object getData() {
        if (root == null) 
            return null;
        return root.data;
    } // end getData()

} // class BinaryTree
