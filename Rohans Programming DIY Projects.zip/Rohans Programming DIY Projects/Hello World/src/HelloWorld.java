
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("IntelliJ is slow editor.");
int myFirstNumber = (10+5) +(2* 10);
int mySecondNumber = 12;
int myThirdNumber = myFirstNumber *2;

int myTotal = myFirstNumber + mySecondNumber + myThirdNumber;

//System.out.println(myTotal);
int myLastOne = 1000 - myTotal;
System.out.println(myLastOne);
	}

}
