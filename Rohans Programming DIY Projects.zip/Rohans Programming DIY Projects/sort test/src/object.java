
public class object {
String name;
int number;

object(String n, int num){
	name = n;
	number = num;
}
public String toString(){
	return name + " " + number;
}
}
