package com.Rohan;

public class Main {

    public static void main(String[] args) {
//        int newScore = calculateScore("Rohan", 500);
//        System.out.println("New score is " + newScore);
//        calculateScore(200);
//        calculateScore();
        double height= calcFeetAndInchesToCentimenters(5 , 6 );
//calcFeetAndInchesToCentimenters(156);

        //calculateScore("Rohan", 500);
    }

    public static int calculateScore(String playerName, int score) {
        System.out.println("Player " + playerName + " has scored " + score + " points");
        return score * 1000;
    }

    public static int calculateScore(int score) {
        System.out.println("Unnamed Player " + " has scored " + score + " points");
        return score * 1000;
        // write your code here
    }

    public static int calculateScore() {
        System.out.println("Unnamed Player " + " has scored " + " no points");
        return 0;
        // write your code here
    }


    public static double calcFeetAndInchesToCentimenters(double feet, double inches) {
        if ((feet < 0) || ((inches < 0) || (inches > 12))) {
            System.out.println("Invalid feet or inches parametes");
            return -1;
        } else if (feet >= 0) {
            double centiMeters = ((feet) * 12 * 2.54) + (inches) * 2.54;
            System.out.println(feet + "feet" + " and " + inches + "inches equals " + centiMeters + "centimeters");
            return centiMeters;
        } else if (inches >= 0 && inches <= 12) {
            double centiMeters = ((feet) * 12 * 2.54) + (inches) * 2.54;
            System.out.println(feet + "feet" + " and " + inches + "inches equals " + centiMeters + "centimeters");
            return centiMeters;
        } else {
            return -1;
        }
    }
    public static double calcFeetAndInchesToCentimenters( double inches) {
            if (inches<0){
                return -1;
            }
            double feet = (int) inches / 12;
            double remaininginches = (int) inches % 12;
            System.out.println( inches + "inches is equal to " + feet +"feet and" +remaininginches+ "inches");
            return calcFeetAndInchesToCentimenters(feet, remaininginches);
        }
    }

