package com.Rohan;

public class Main {

    public static void main(String[] args) {
        // write your code here
        // a mile is equal to 1.609344 kilometers
        // there are 50 keywords in java
        double kilometers = (100 * 1.609344);
        int highScore = 50;
        if (highScore == 50) {
            System.out.println("This is an expression");
        }


    }
}
