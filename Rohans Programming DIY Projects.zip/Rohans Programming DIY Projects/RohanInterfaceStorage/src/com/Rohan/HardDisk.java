package com.Rohan;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by Rohan on 12/28/2016.
 */
public class HardDisk implements IStorage {

    private String id;
    private String content1;
    private String content2;
    private String content3;
    LinkedList<String> retrievedContent;

    @Override
    public LinkedList<String> storeContent(String id, String content1, String content2, String content3) {
        retrievedContent = new LinkedList<>();
        retrievedContent.add(0, id);
        retrievedContent.add(1, content1);
        retrievedContent.add(2, content2);
        retrievedContent.add(3, content3);
        System.out.println("Now storing with id "+ id + retrievedContent.toString());
        return retrievedContent;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent1() {
        return content1;
    }

    public void setContent1(String content1) {
        this.content1 = content1;
    }

    public String getContent2() {
        return content2;
    }

    public void setContent2(String content2) {
        this.content2 = content2;
    }

    public String getContent3() {
        return content3;
    }

    public void setContent3(String content3) {
        this.content3 = content3;
    }

    public List<String> getRetrievedContent() {
        return retrievedContent;
    }

    public void setRetrievedContent(LinkedList<String> retrievedContent) {
        this.retrievedContent = retrievedContent;
    }

    @Override
    public LinkedList<String> retrieveContent(String id) {
        if (id != retrievedContent.get(0)) {
            System.out.println("The content is not in stored media");
        } else {
            return retrievedContent;
        }
        return retrievedContent;
    }

    @Override
    public String toString() {
        return retrievedContent + " was stored in media";
    }
}

