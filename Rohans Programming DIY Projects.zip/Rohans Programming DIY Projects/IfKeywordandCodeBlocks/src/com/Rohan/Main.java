package com.Rohan;

public class Main {

    public static void main(String[] args) {

        boolean gameOver = true;
        int score = 10000;
        int levelCompleted = 8;
        int bonus = 200;

//        if (score == 5000){
//            System.out.println("Your score was " + score);
//        } else if (score < 7000) {
//            System.out.println("Score calculating");
//        }else{
//            System.out.println("Score was greater than 7000");
//        }


        if(gameOver ){
            int finalScore = score + (levelCompleted * bonus);
            System.out.println("Your final score was " +finalScore);
        }


        boolean gameOver2 = true;
        int score2 = 9000;
        int levelCompleted2 = 9;
        int bonus2 = 200;

        if(gameOver ){
            int finalScore = score2 + (levelCompleted2 * bonus2);
            System.out.println("Your final score was " +finalScore);
        }


       score2 = 9000;
        levelCompleted2 = 9;
        bonus2 = 200;

        if(gameOver ){
            int finalScore = score2 + (levelCompleted2 * bonus2);
            System.out.println("Your final score was " +finalScore);
        }



        // write your code here
    }
}
