package com.Rohan;

/**
 * Created by Rohan on 12/28/2016.
 */
public class DeskPhone implements ITelephone {
    private int myNumber;
    private boolean isRinging;

    public DeskPhone(int myNumber) {
        this.myNumber = myNumber;
    }

    @Override
    public void powerOn() {
        System.out.println("No action taken, desk phone does not have a power button");

    }

    @Override
    public void dial(int phonenumber) {
        System.out.println("Now ringing " + phonenumber);

    }

    @Override
    public void answer() {
        if(isRinging == true){
            System.out.println("Picked up phone");
            isRinging = false;
        }

    }

    @Override
    public boolean callPhone(int phonenumber) {
        if(phonenumber==myNumber){
            isRinging = true;
            System.out.println("ring ring");
        }else{
            isRinging = false;
        }
        return isRinging;
    }

    @Override
    public boolean isRinging() {
        return isRinging;
    }
}
