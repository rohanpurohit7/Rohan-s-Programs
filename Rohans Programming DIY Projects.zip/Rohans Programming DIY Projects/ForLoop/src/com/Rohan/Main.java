package com.Rohan;

public class Main {

    public static void main(String[] args) {

        //   System.out.println("The interest rate for the investment is " + calculate5yearInterestRate);
//
//        for(int r = 0; r < 5; r++){
//            System.out.println("In Loop " + r);
//        }
//
//        for (int i = 8; i >=2; i--) {
//            System.out.println("The interest rate for the 100 investment at " +i +" % is " + String.format("%.2f",calculateInterestRate(100, i)));
//        }

//
        // System.out.println("The number is a  "+ isPrime(15) +" prime");
        int count = 0;
        for (int n = 2; n < 100; n++) {
                if (isPrime(n)) {
                System.out.println(n);
                count++;
                    System.out.println("The Number "+ n +"is prime.");
                if (count == 10) {
                    System.out.println("found ten primes");
                    break;
                }


            }
        }
    }



    private static boolean isPrime(int n){
        if(n == 1){
            return false;
        }
        for (int i=2; i<=(long)Math.sqrt(n);i++){
            if(n%i ==0){
                return false;
            }
        }
        return true;
    }
    // write your code here

    public static double calculateInterestRate(double amount, double interestRate) {
        return (amount * (interestRate / 100));
    }
}




