package com.Rohan;

/**
 * Created by Rohan on 12/19/2016.
 */
public class GamePlayer {

    public String name;
    public int health;
    public String weapon;

    public void loseHealth(int damage){
        this.health = this.health-damage;
        System.out.println("The player"+ name +" has lost"+ damage+ "health points.");
        if(this.health <= 0){
            System.out.println("Player knocked out");
            // reduce number of lives
        }
    }

    public int healthRemaining(){

        System.out.println(this.health);
        return this.health;
    }

//    public GamePlayer(String name, int health, String weapon) {
//        this.name = name;
//        this.health = health;
//        this.weapon = weapon;
//    }
}
