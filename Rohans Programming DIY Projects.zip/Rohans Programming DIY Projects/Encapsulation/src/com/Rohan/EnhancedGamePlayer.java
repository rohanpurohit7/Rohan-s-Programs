package com.Rohan;

/**
 * Created by Rohan on 12/19/2016.
 */
public class EnhancedGamePlayer {
    private String name;
    private int health=100;
    private String weapon;

    public EnhancedGamePlayer(String name, int health, String weapon) {
        this.name = name;
        if (health >0 && health<= 100){
            this.health = health;
        }
        this.weapon = weapon;
    }

    public int getHealth() {
        System.out.println(health);
        return health;
    }

    public void loseHealth(int damage){
        this.health = this.health-damage;
        System.out.println("The player"+ name +" has lost"+ damage+ "health points.");
        if(this.health <= 0){
            System.out.println("Player knocked out");
            // reduce number of lives
        }


}}

