package com.Rohan;

/**
 * Created by Rohan on 12/19/2016.
 */
public class Printer {
    private String tonerLevel;
    private int tonerPercent;
    private int pagePrinted;
    private int numberOfPages;
    private boolean isDuplexPrinter;
    private int refillPercent;
    private String printContent;
    private int printDocument=0;

    public Printer(int tonerPercent,  boolean isDuplexPrinter) {
        this.tonerPercent = tonerPercent;
        this.isDuplexPrinter = isDuplexPrinter;

    }

    public int reduceToner(int pagePrinted){
        if((pagePrinted>=0) && (pagePrinted<= 100)){
            tonerPercent -= 10;}
            else if((pagePrinted>100) && (pagePrinted<= 1000)){
                tonerPercent -= 50;
            }
            System.out.println("Toner ink is now at "+ tonerPercent);
        return tonerPercent;
        }


    public void fillUpToner( int refillPercent){
        while (tonerPercent >=0 && tonerPercent<= 100){
        this.tonerPercent =+ refillPercent;
            System.out.println("Toner filled up to " + tonerPercent+ "%");
            break;
    }
    }

    public int getTonerPercent() {
        System.out.println("Toner is currently at "+ tonerPercent + "%");
        return tonerPercent;
    }

    public int printPage(int numberOfPages){
        if (isDuplexPrinter == true){
            pagePrinted = numberOfPages/2;
            System.out.println("Printing in duplex mode, now printed "+ pagePrinted+ " pages");}
            else if (isDuplexPrinter== false){
            pagePrinted = numberOfPages;
            System.out.println("Printing in standarad mode, now printed " + pagePrinted +" pages");}

        reduceToner(pagePrinted);
        return pagePrinted;

    }
}
