package com.Rohan;

public class Main {

    public static void main(String[] args) {

        IStorage sandisk;
        sandisk = new HardDisk();
        sandisk.storeContent("1", "A pair of headphones", "A watch", "A iphone");
        sandisk.retrieveContent("1");


	// write your code here
    }
}
