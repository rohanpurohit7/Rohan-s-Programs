package com.Rohan;

import java.util.List;

/**
 * Created by Rohan on 12/28/2016.
 */
public interface IStorage {

    List<String> storeContent(String id, String content1, String content2, String content3);
    List<String> retrieveContent(String id);

}
