package com.Rohan;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static GroceryList mygroceryList = new GroceryList();

    public static void printInstructions(){
        System.out.println("\nPress ");
        System.out.println("0 to print choice options");
        System.out.println("1 to print list of grocery items");
        System.out.println("2 to add item to the list");
        System.out.println("3 to modify grocery item");
        System.out.println("4 to remove item");
        System.out.println("5 to search for item");
        System.out.println("6 to quit");
    }

    public static void addItem(){
        System.out.print("Please enter item to add");
        mygroceryList.addGroceryItem(scanner.nextLine());
    }


    public static void modifyItem(){
        System.out.print("Please enter an item name to modify");
        String itemName = (scanner.nextLine());
        scanner.nextLine();
        System.out.print("Enter replacement item: ");
        String newItem = scanner.nextLine();
        mygroceryList.modifyGroceryItem(itemName,newItem);// position is for array. itemNo is for user view of list
    }

    public static void removeItem(){
        System.out.print("Please enter an item name to remove");
        String itemName = (scanner.nextLine());
        scanner.nextLine();
        mygroceryList.removeGroceryItem(itemName);
    }

    public static void searchForItem() {
        System.out.print("Item to search for : ");
        String searchItem = scanner.nextLine();
        if (mygroceryList.onFile(searchItem)) {
            System.out.println("Found item: " + searchItem + " in the list");
        } else {
            System.out.println("Item is not in the list");
        }}

        public static void processArrayList(){
            System.out.println("Now processing groceryList");
            ArrayList<String> newList = new ArrayList<String>();
            newList.addAll(mygroceryList.getGroceryList()); // copty to newArrayList

            ArrayList<String> processedList = new ArrayList<String>(mygroceryList.getGroceryList()); // copy to arraylist

            String[] myArray =  new String [mygroceryList.getGroceryList().size()] ;
            myArray= mygroceryList.getGroceryList().toArray(myArray);  // copy to a normal array  after specifyin size/
        }

    public static void main (String[]args)
    {

        boolean quit = false;
        int choice =0;
        printInstructions();
        while(! quit){
            System.out.println("Enter your choice");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch(choice){
                case 0:
                    printInstructions();
                    break;
                case 1:
                    mygroceryList.printGroceryList();
                    break;
                case 2:
                    addItem();
                    break;
                case 3:
                    modifyItem();
                    break;
                case 4:
                    removeItem();
                    break;
                case 5:
                    searchForItem();
                    break;
                case 6:
                    processArrayList();
                case 7:
                    quit = true;
                    break;

            }


        }

    }
}
