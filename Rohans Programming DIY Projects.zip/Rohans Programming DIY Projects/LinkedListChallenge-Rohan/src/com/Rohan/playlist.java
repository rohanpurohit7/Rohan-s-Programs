package com.Rohan;

import java.util.LinkedList;

/**
 * Created by Rohan on 12/27/2016.
 */
public class playlist {
    LinkedList<Song> playlist;


}
