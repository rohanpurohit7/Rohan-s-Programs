package com.Rohan;

public class Main {

    public static void main(String[] args) {
//	// write your code here
//        int count = 0;
//        while (count != 5){
//            System.out.println("The count value is " + count);
//            count ++;
//        }
//        int count = 0;
//        while (true ){
//            if (count == 5){
//                break;
//            }
//            else{
//                System.out.println("The count value is " + count);
//                count ++;
//            }
//        }
//    }

        int count = 0;
        int evenNumber =0;
        do {
            isEvenNumber(count);
            if(isEvenNumber(count)== true && evenNumber<5){
                System.out.println("Even number is "+ count);
                evenNumber++;
                System.out.println("We found "+ evenNumber+ " even numbers");

            }
            count++;
        } while (count != 100);}


        public static boolean isEvenNumber (int n ){

            if (n %2 == 0){
                return true;
            }else{
                return false;
            }
    }
    }

