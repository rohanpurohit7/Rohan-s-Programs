import java.io.*;
import java.util.Scanner;



public class InfixEvaluator {
public static void main (String[] args) throws IOException
{
	String input = null;
	String Intopostoutput = null;

	
		Scanner scan =  new Scanner(System.in);
		System.out.print("Enter an infix expression: ");
		input = scan.nextLine();
		while(input.equals("")) {
			System.out.println("Please enter a valid Infix expression.");
			input = scan.nextLine();
		}
			
		
		InfixToPostfixParens inToPost = new InfixToPostfixParens();
		try {
			Intopostoutput = inToPost.convert(input);
		} catch (InfixToPostfixParens.SyntaxErrorException e) {// a try-catch block to deal with input errors.
			// TODO Auto-generated catch block
			System.out.print(e.getMessage());
			e.printStackTrace();
		}//do the translation
		System.out.println("");
		System.out.println("The postfix expression is: " + Intopostoutput + '\n');// the postfix expression obtained after conversion
		
		PostfixEvaluator postfixsolve = new PostfixEvaluator();
		

	  int output = 0;
	try {
		output = postfixsolve.eval(Intopostoutput);
	} catch (PostfixEvaluator.SyntaxErrorException e) {
		// TODO Auto-generated catch block
		System.out.print(e.getMessage());
		e.printStackTrace();
	}
	  
	  System.out.println("The evaluation of the postfix expression yields the value of: " + output);
	  
	  
}//end main
//------------

	}


