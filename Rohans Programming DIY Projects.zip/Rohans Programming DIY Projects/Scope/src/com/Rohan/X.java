package com.Rohan;

/**
 * Created by Rohan on 1/5/2017.
 */
public class X {
    private int x;

    public X(int x) {
        this.x = x;
    }

    public  void printTable(){
        for(int i =1; i<13; i++){
            System.out.println(i +" * "+ x + " equals " + (i*x));
        }
    }



}
