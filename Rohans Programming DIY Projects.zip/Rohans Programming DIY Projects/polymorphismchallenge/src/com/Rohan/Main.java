package com.Rohan;


class ToyotaCorolla extends Car {
        private String model;
        private boolean lease;



        public ToyotaCorolla(String name, String color, String model, boolean lease, boolean startEngine) {
            super(4, 6, name, color);
            this.name = name;
            this.color = color;
            this.model = model;
            this.lease = lease;
            this.startEngine = startEngine;
        }

        public String getModel() {
            return model;
        }

        public boolean isLease() {
            return lease;
        }

        @Override
        public String getName() {
            return super.getName();
        }

        @Override
        public int getCylinders() {
            return super.getCylinders();
        }

        @Override
        public String getColor() {
            return super.getColor();
        }

    @Override
    public String getWheels() {
        return super.getWheels();
    }
}

class Car {

    private int wheels;
    private int cylinders;
    public String name;
    public String color;
    public boolean startEngine;
    public int newspeed;
    public int currentvelocity;
    public int accelerate;

    public Car(int wheels, int cylinders, String name, String color) {
        this.wheels = wheels;
        this.cylinders = cylinders;
        this.name = name;
        this.color = color;

    }

    public String getWheels() {
       System.out.println("Now in parent class getWheels method");
        return "All cars have four wheels";
    }

    public int getCylinders() {
        System.out.println("The car has " + cylinders + "cylinders");
        return cylinders;
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }


    public boolean startEngine(boolean turnKey) {
        if (turnKey == true) {
            startEngine = true;
            System.out.println("Vehicle is starting");
            currentvelocity = 0;
        } else if (turnKey == false) {
            startEngine = false;
            currentvelocity = 0;
            System.out.println("Please turn the ignition key");
        }
        return startEngine;
    }

    public void brake(int brake) {

            currentvelocity -= brake;
            System.out.println("Now breaking by" + brake + "mph , New speed is " + currentvelocity + "mph");

        if (currentvelocity <= 0) {
            System.out.println("The car has stopped.");
            startEngine(false);
        }
    }

    public void accelerate(int accelerate) {
        currentvelocity += accelerate;
        System.out.println("Current velocity is " + currentvelocity);
        if (currentvelocity >= 80){
                brake(30);
                System.out.println("Autodriver slowed speed by "+ 30 +"mph." + "/n Current velocity is "+ currentvelocity);
           } else if (currentvelocity<=0){
                    System.out.println("The car has stopped.Shutting down engine.");
                    startEngine(false);
                }
            }

    }

 class HondaCRV extends Car {
    private String model;
    private boolean lease;



    public HondaCRV(String name, String color, String model, boolean lease, boolean startEngine) {
        super(4, 6, name, color);
        this.name = name;
        this.color = color;
        this.model = model;
        this.lease = lease;
        this.startEngine = startEngine;
        System.out.println("Now testing car  " + name);
    }

    public String getModel() {
        return model;
    }

    public boolean isLease() {
        return lease;
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public int getCylinders() {
        return super.getCylinders();
    }

    @Override
    public String getColor() {
        return super.getColor();
    }

    @Override
    public String getWheels() {
        return super.getWheels();
    }
}





public class Main {


    public static void main(String[] args) {
        //Car toyota = new Car(4, 6, "RPMobile", "Blue", 10);
        ToyotaCorolla rp = new ToyotaCorolla("Toyota", "Blue", "LE", true, true);
        rp.startEngine(true);
        rp.accelerate(90);
        rp.brake(60);
        rp.getCylinders();
        rp.getModel();
        System.out.println(rp.getWheels());

        HondaCRV rcp = new HondaCRV("Honda", "Black", "LE", false, true);
        rcp.accelerate(40);
        rcp.accelerate(50);
        rcp.brake (60);
        System.out.println(rcp.getName());

    }

}


	// write your code here

