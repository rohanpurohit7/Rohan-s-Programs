package com.Rohan;

/**
 * Created by Rohan on 12/18/2016.
 */
public class Car extends Vehicle {

    private String model;
    private String color;
    private String steering;
    private int currentGear;
    private int currentVelocity;
    private String currentDirection;


    public Car(String typeofVehicle, int wheels, int gears, String model, String color, String steering, String currentDirection) {
        super(typeofVehicle, model, wheels, gears);
        this.model = model;
        this.color = color;
        this.steering = steering;
        this.currentDirection= "North";
    }

    @Override
    public String getModel() {

        System.out.println("The vehicle has the following model" + model);
        return model;
    }

    public String getColor() {
        System.out.println("The vehicle has the following color: " + color);
        return color;
    }

    public String getSteering() {
        System.out.println("The vehicle has the following steering option " + steering);
        return steering;
    }

    public void getGear() {
        super.getGears();

    }

    @Override
    public void setModel(String model) {
        this.model = model;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSteering(String steering) {
        System.out.println("The vehicle has been set to the following steering" + steering);
        this.steering = steering;
    }


    public void changeVelocity(int speed, String direction){
       move(speed, direction);
        System.out.println("Car.changeVelocity:  Velcoity: "+ speed + "direction"+ direction);

    }

    public void changeGear(int currentGear){
        this.currentGear = currentGear;
        System.out.println("Car.setCurrentGear(): changed to "+this.currentGear + "gear");
    }

    public String getCurrentDirection() {
        return currentDirection;
    }

    public void setCurrentDirection(String currentDirection){
        this.currentDirection= currentDirection;
    }

    @Override
    public void stop() {
        super.stop();

    }
}
