
public class TestProj4 {
public static void main(String[]args){
	ArrayOrderedList x = new ArrayOrderedList();// a new ArrayOrderedList created.
	x.add("Donatello");
	x.add("Leonardo");
	x.add("Michaelangelo");
	x.add("Raphael");// so I added four elements into the list.
	
	//Test toString method
	System.out.println("Test Project 4: test for toString method   --->");
	System.out.println(x.toString());// print's out the ArrayOrderedList's elements using the toString method.
	
	//Test size method
	if(x.size()==4)
		System.out.println("The size method correctly computes the size of the list as 4");
		else
			System.out.println("The size method does not work.");

	//Test indexOf method
	if((x.indexOf("Michaelangelo")== 2))
		System.out.println("The indexOf method correctly yields Michaelangelo at the index value of 2");
	else
		System.out.println("The indexOf method does not work.");
			
	
	
	//Test get method
	
	if((x.get(3)=="Raphael"))
		System.out.println("The get method correctly gets Raphael as the value at index 3");
	else
		System.out.println("The get method does not work.");
		
	
	//Test set method
	
	x.set(3, "Master Splinter");// entry Raphael mutated into Master Splinter
	if(x.get(3)=="Master Splinter")
		System.out.println("The set method mutated the entry for Raphael into Master Splinter, so the method works.");
	else
		System.out.println("The set method does not work.");
	
// Clear out old ArrayOrderedList and assign new Integer values at the elements.
    System.out.println("");
    System.out.println("The elements of the ArrayOrderedList are reset into new Integer values--->.");
	
    x = new ArrayOrderedList();
	x.add( new Integer(1));
	x.add( new Integer(15));
	x.add(new Integer(3));
	x.add(new Integer(15));
	x.add(new Integer(77));
	x.add(new Integer(33));
	x.add(new Integer(34));
	
	
	System.out.println(x.toString());//

	// Test firstIndexOf method
	if(x.firstIndexOf(new Integer(15))==2)// compare the value of '2' first occurence to expected index 2. 
		System.out.println("The first instance of the value 15 occurs at index value of 2, the firstIndexOf method works");
	else
		System.out.println("Thr first instance of method does not work.");
	
	//Test lastIndexOf method
	if(x.lastIndexOf(new Integer(15))==3)
		System.out.println("The last instance of the value 15 occurs at index value of 3, the lastIndexOf method works");
	else
		System.out.println("The last instance of method does not work.");
	
	//Test removeAllInstancesOf method and boolean contains method.
	x.removeAllInstancesOf(new Integer(15));// implements and tests removeAllInstancesOf method
	
	if(x.contains(new Integer(15))== false)// tests boolean contains method 
		System.out.println("The result from the  boolean contain method validates that the removeAllInstancesOf method works, ie.. the value of 15 was removed from the ArrayOrderedList.");
	else
		System.out.println("The removeAllInstancesOf method does not work.");
	
	
	System.out.println(x.toString());// prints out the modified list.
	
	//Test the binary Search method.
	if(x.BinarySearch(new Integer(34))== 3)
	System.out.println("The Binary Search correctly computes the index value of 3 for the element value of 34.");
	else
		System.out.println("The Binary Search method does not work.");
	
		}
	
}// end TestProj4

