
public class ArrayOrderedList {

	// The default capacity of the Array is specified below//
	private static final int INITIAL_CAPACITY = 10;
	
	// The underlying data array//
	private Comparable[] theData;
	
	private int size = 0;// the current size of the list.
	
	// CONSTRUCTOR-->
	// The constructor -constructs an empty list with initial capacity of 10//
	public ArrayOrderedList(){
		theData = new Comparable[INITIAL_CAPACITY];
	}
	
	
	
	// SIZE METHOD-->
	// The size method below gets the current size of the ArrayOrderedList//
	public int size(){
		return size;
		
	}
	
public int BinarySearch(Comparable target){
	return BinarySearch(0,size-1,target);
}


// INDEX-OF METHOD-->
//The indexOf method-Searches for target and returns the position of an occurrence, 
//or -1 if it is not in the ArrayOrderedList//
public int indexOf(Comparable target){
	return BinarySearch(0,size-1,target);
}

//FIRST INDEX-OF METHOD-->
//Searches for target and returns the position of the first occurrence,
//or -1 if it is not in the ArrayOrderedList.
//...
public int firstIndexOf(Comparable target){
	for(int i = 0;i<size;i++){
		Comparable temp = theData[i];
		if(temp.compareTo(target) == 0)
		return i;
		}return -1;

	
	
}


//LAST INDEX-OF METHOD-->
//Searches for target and returns the position of the last occurrence,
//or -1 if it is not in the ArrayOrderedList.
//...
public int lastIndexOf(Comparable target){
	for(int i = size-1;i>=0;i--){
		Comparable temp = theData[i];
		if(temp.compareTo(target)==0)
			return i;
	}
	return-1;
}


// GET METHOD-->
//the Get method(accessory method)-returns a reference to the element at position index//
public Comparable get(int index){
	if(index<0||index>=size)
		throw new IllegalArgumentException();
	return theData[index];
}


//SET METHOD-->
//the Set method(mutator method)-replaces the element at position index with anEntry.Returns the previous value.
//If anEntry does not preserve the list's natural order, throws an IllegalArgumentException.//
public Comparable set(int index,Comparable anEntry){
	if(index<0|| index>= size)
		throw new IllegalArgumentException();
	Comparable temp = theData[index];
	theData[index]= anEntry;
	return temp;
}


//BOOLEAN-ADD METHOD -->
// the Boolean add method-Inserts a reference to anEntry into the list,
// while preserving the list's natural order.Always returns true.//
	public boolean add(Comparable anEntry){
		if(size>=theData.length){
			reallocate();
		}
		if(size==0){
			size++;
			theData[0]=(anEntry);
			return true;
		}
		int lo = 0;
		int hi =  size-1;
		int middle = (lo+hi)/2;
		int index;
		int compresult=0;
		
		while(lo<=hi){
			middle = (lo+hi)/2;
			compresult =(anEntry.compareTo(theData[middle]));
			if(compresult<0)
				hi = middle -1;
			else if(compresult>0)
				lo = middle+1;
			else if(compresult == 0)
				break;
		}//end while
		if(compresult>0)
		{
			for(int i = size;i>middle+1;i--){
				theData[i]=theData[i-1];
			}//end for loop
			theData[middle+1]=(anEntry);
		}else{
			for(int i=size;i>middle;i--){
				theData[i]=theData[i-1];
				theData[middle]=(anEntry);
			}
		}
		// Insert
		size++;
		return true;
	}
	
	
	//BOOLEAN-REMOVE METHOD-->
	//Removes one instance of an item that matches the target and shifts the items following it
	// to fill the vacated space.Returns true if match is found;else returns false//
	public boolean remove(Comparable element){
		int index = indexOf(element);
		if(index == -1)
			return false;
		for(int i = index; i<size-1;i++){
			theData[i]=theData[i+1];
		return true;}
		return false;}

	
		//COMPARABLE-REMOVE METHOD-->
		// Returns and removes the item at position index and shifts the items following it to fill the 
		// vacated space//
		public Comparable remove(int index){
			if(index<0|| index>size)
				throw new IllegalArgumentException();
			Comparable temp = theData[index];
			for(int i = index; i<size-1;i++){
				theData[i]=theData[i+1];
			}size--;
			return temp;
		}
		
		//REMOVE ALL INSTANCES OF METHOD-->
		//Removes all instances of items that match the target and shifts the remaining items
		//that follow to fill the vacated space or spaces.
		//...
		public void removeAllInstancesOf
	    (Comparable element){
			int index = firstIndexOf(element);
			while(index!= -1){
				remove(index);
				index = firstIndexOf(element);
			}
			
		}
		
		//BOOLEAN-CONTAINS METHOD-->
		//Returns true if the list contains the specified target, else returns false//
		public boolean contains(Comparable target){
				if(BinarySearch(0,size-1,target)>=0)
					return true;
				else
					return false;
			}
		//TO-STRING METHOD-->
		// Returns a string representation of this list, in which each entry in the list is seperated from
		// the next entry by one blank character.
		public String toString(){
			String result = "";
			for(int i = 0;i<size;i++)
				result+=theData[i].toString()+"\n";
			return result;
		}
		
		
		//BINARY SEARCH METHOD-->
		//Looks for a match to target in the index range[lo,hi] of this list. If a match if found
		//returns the index of the position at which the match was found; otherwise, returns -1;//
		private int BinarySearch(int lo,int hi, Comparable target){
			if(lo>hi)
				return -1;
			else{
				int middle = (lo+hi)/2;// gets the next index
				int compResult = target.compareTo(theData[middle]);
				if(compResult==0)
					return middle;// base case for successful search.
				else if(compResult<0)
					return BinarySearch(lo,middle-1,target);
				else
					return BinarySearch(middle+1, hi, target);
			}
		}
		
		
		//REALLOCATE METHOD-->
		// Allocates a new array, with twice the capacity of the current array, to hold the list//
		private void reallocate(){
			int capacity =  theData.length*2;
			Comparable[]newDirectory =  new Comparable[capacity];
			System.arraycopy(theData,0,newDirectory,0,theData.length);
			theData = newDirectory;
		}
	
	}// end class ArrayOrderedList


