package com.Rohan;
import java.util.Scanner;
public class Main {


        // write your code here
//        int[] exampleArray = new int[10];
//
//        printArray(exampleArray);}
//
//    public static void printArray(int[] myArray) {
//        for (int i = 0; i < myArray.length; i++) {
//            myArray[i] = i* 10;
//            System.out.println("Element " + i + " has value " + myArray[i]);
//        }


    private static Scanner scan = new Scanner(System.in);

        public static void main (String [] args){

            int[] myArray = getIntegers(5);
            for(int i =0; i<myArray.length; i++){
                System.out.println("Element "+ i +" has value of " + myArray[i]);
            }
            System.out.println("The average is "+ getAverage(myArray));
        }

        public static int[] getIntegers(int number){
            System.out.println("Enter " +number + "integer values.\r" );
            int[] containerArray = new int[number];

            for (int i =0; i<containerArray.length; i++){
                containerArray[i] = scan.nextInt();
            }return containerArray;
        }

        private static double getAverage(int[] array){
            int sum = 0;
            for(int i=0; i<array.length; i++){
                sum+= array[i];
            }
            double average = (double) sum/ (double) array.length;
            return average;
        }


}

//


