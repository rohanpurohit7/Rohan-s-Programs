package com.Rohan;

public class Main {

    public static void main(String[] args) {
	// write your code here

//        Animal animal = new Animal ("Tiger", 1, 1, 5, 500);
//        Dog dog = new Dog("Bruce", 2, 70, 2, 4, 32,1, "Yellow");
//        dog.eat();
//        dog.walk();
      //  dog.run();

//        Fish fish = new Fish("Goldie", 1, 2, 2, 2, 2, "Golden", "Goldfish");
//        fish.swim(3);
//        fish.rest();

//
//        Vehicle vehicle1 = new Vehicle("Car","corolla", 4, 4);
//        Car car = new Car( "Car", 4, 4, "Corolla","Blue", "Automatic");
//        car.getColor();
//        car.getGear();
//        car.getModel();
//        car.getSteering();

        ToyotaCorolla Rohan = new ToyotaCorolla("Thirty Six Months Service");
        Rohan.setSteering("Fourty Five");
        Rohan.accelerate(25);
        Rohan.getCurrentDirection();
        Rohan.getCurrentVelocity();
        Rohan.getModel();



    }
}
