package com.Rohan;

/**
 * Created by Rohan on 12/18/2016.
 */
public class Vehicle {

    private String typeofVehicle;
    private String currentDirection;
    private int currentVelocity;


    public Vehicle(String typeofVehicle, String model, int wheels, int gears) {
        this.typeofVehicle = typeofVehicle;
        this.model = model;
        this.wheels = wheels;
        this.gears = gears;
    }

    private String model;
    private int wheels;
    private int gears;

    public String getTypeofVehicle() {
        return typeofVehicle;
    }

    public String getModel() {
        return model;
    }

    public void setTypeofVehicle(String typeofVehicle) {
        this.typeofVehicle = typeofVehicle;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setWheels(int wheels) {
        this.wheels = wheels;
    }

    public void setGears(int gears) {
        this.gears = gears;
    }

    public int getWheels() {
        return wheels;

    }

    public int getGears() {
        return gears;
    }

    public void steer(int direction) {
        this.currentDirection += direction;
        System.out.println("Vehicle.steer(): Steering at " + currentDirection + " degrees");
    }

    public void move(int velocity, String direction) {
        currentVelocity = velocity;
        currentDirection = direction;
        System.out.println("Vehicle.move(): Moving at current" + currentVelocity + "in " + currentDirection);
           }

    public String getCurrentDirection() {
        return currentDirection;
    }

    public int getCurrentVelocity() {
        return currentVelocity;
    }
    public void stop(){
        this.currentVelocity = 0;
    }
}

