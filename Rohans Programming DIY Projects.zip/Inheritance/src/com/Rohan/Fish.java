package com.Rohan;

/**
 * Created by Rohan on 12/18/2016.
 */
public class Fish extends Animal {

    private int eyes;
    private int fins;
    String color;
    String type;
    private int gills;

    public Fish(String name, int size, int weight, int eyes, int fins, int gills, String color, String type) {
        super(name, 1, 1, size, weight);
        this.eyes = eyes;
        this.fins = fins;
        this.color = color;
        this.type = type;
        this.gills = gills;
    }


        public void rest(){
            System.out.println("The fish is resting");

    }

    private void moveMuscles(){
        System.out.println("The fish is moving muscles()" );
        move(3);
    }

    private void moveBackFins(){
        System.out.println("The fish is moving back fins ");
        move(3);
    }

    public void swim (int speed){
        moveMuscles();
        moveBackFins();
        super.move(speed);
    }
    }

