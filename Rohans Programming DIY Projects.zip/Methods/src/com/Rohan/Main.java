package com.Rohan;

public class Main {

    public static void main(String[] args) {
        boolean gameOver = true;
        int score = 9000;
        int levelCompleted = 9;
        int bonus = 200;

        int highScore = calculateScore(gameOver, score, levelCompleted, bonus);
        System.out.println("Your final score was " +highScore);

        displayHighScorePosition("Bruce", 1 );
System.out.println(score);
       int highScorePosition = calculateHighScorePosition(500);
System.out.println(highScorePosition);

    }

    public static String displayHighScorePosition (String playerName, int position){
       String Summary = (playerName + " is currently at " + position);
        System.out.println(Summary);
        return Summary;
        }

        public static int calculateHighScorePosition (int score ) {
            if(score > 1000) {
                return 1;
            } else if(score > 500 && score <= 1000) {
                return 2;
            } else if(score > 100 && score <= 500) {
                return 3;
            } else{
                return 4;
            }
        }



    public  static int calculateScore (boolean gameOver, int score, int levelCompleted, int bonus){
        if(gameOver ){
            int finalScore = score + (levelCompleted * bonus);
            finalScore += 1000;
            return finalScore;
        }else{
            return -1;
        }
    }
}
