package com.Rohan;

import java.util.ArrayList;


class IntClass{
    private int myValue;

    public IntClass(int myValue) {
        this.myValue = myValue;
    }

    public int getMyValue() {
        return myValue;
    }

    public void setMyValue(int myValue) {
        this.myValue = myValue;
    }
}

public class Main {

    public static void main(String[] args) {
	// write your code here

//       // String [] myArray = new [10];
//
//        ArrayList<String> anArray = new ArrayList<>();
//        anArray.add("Object");
//
//        ArrayList<IntClass> intArray = new ArrayList<>(10);
//        intArray.add(new IntClass(10));
//
//
//        Integer integer = new Integer(10);
//        Double  num = new Double(12.0);
//
//
//        ArrayList<Integer> myArray = new ArrayList<Integer>(10);
//        for(int i =0; i<10; i++){
//            myArray.add(Integer.valueOf(i));
//    }
//
//    for(int i =0; i<10; i++){
//        System.out.println(i + "-->" + myArray.get(Integer.valueOf(i)));
//    }
//}
//
//Integer myIntNum = 56; // Integer.valueOf(56);
//

    ArrayList<Double> myDoubleArray = new ArrayList<>();

    for(double j =0.0; j < 10.0; j+=0.5){
        myDoubleArray.add(Double.valueOf(j));  // autoboxing
    }

    for (int i =0; i<myDoubleArray.size();i++){
        double value =  myDoubleArray.get(i).doubleValue(); // unboxing
        System.out.println(i + "-->"+  value);
    }


        for(double j =0.0; j < 10.0; j+=0.5){
            myDoubleArray.add(j);  // autoboxing- short format makes double value of
        }

        for (int i =0; i<myDoubleArray.size();i++){
            double value =  myDoubleArray.get(i); // unboxing - short format gets double value of
            System.out.println(i + "-->"+  value);
        }

}}
