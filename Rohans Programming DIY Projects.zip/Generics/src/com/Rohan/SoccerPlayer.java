package com.Rohan;

/**
 * Created by Rohan on 1/4/2017.
 */
public class SoccerPlayer extends Player {
    public SoccerPlayer(String name) {
        super(name);
    }
}
