package com.Rohan;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // write your code here
//        ArrayList <Integer> items = new ArrayList<>();
//        items.add(1);
//        items.add(2);
//        items.add(3);
//        items.add(4);
//        items.add(5);
//
//        printDoubled(items);

        FootballPlayer joe = new FootballPlayer("Joe");
        BaseballPlayer pat = new BaseballPlayer("Pat");
        SoccerPlayer jack = new SoccerPlayer("Jack");
        FootballPlayer rohan = new FootballPlayer("Rohan");

        Team<FootballPlayer> adelaideCrows = new Team<>("adelaideCrows");
        adelaideCrows.addPlayer(joe);

        Team<FootballPlayer> india = new Team<>("india");
        india.addPlayer(rohan);


        Team<BaseballPlayer> baseballteam = new Team<>("cubs");
        baseballteam.addPlayer(pat);

        System.out.println(adelaideCrows.numPlayers());
        System.out.println(baseballteam.numPlayers());

        india.matchResult(adelaideCrows, 5, 1);
        adelaideCrows.matchResult(india, 1, 5);

        System.out.println(india.getTeamName() + india.ranking());
        System.out.println(adelaideCrows.getTeamName() + adelaideCrows.ranking());


//        ArrayList<Team> leagueteams= new ArrayList<Team>();
//
//
//        leagueteams.add(adelaideCrows);
//        leagueteams.add(india);
//        Collections.sort(leagueteams);
//        for(int i = 1; i<leagueteams.size();i++){
//            System.out.println(leagueteams.get(i));
//        }


    }
    private static void  printDoubled(ArrayList <Integer> items){
        for (int i: items){
            System.out.println( i *2);
        }
    }
}
