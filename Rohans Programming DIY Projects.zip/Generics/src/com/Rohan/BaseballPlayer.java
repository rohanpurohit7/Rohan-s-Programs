package com.Rohan;

/**
 * Created by Rohan on 1/4/2017.
 */
public class BaseballPlayer extends Player{

    public BaseballPlayer(String name) {
        super(name);
    }
}
