package com.Rohan;

/**
 * Created by Rohan on 1/4/2017.
 */
public abstract class Player {
    private String name;

    public Player(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

