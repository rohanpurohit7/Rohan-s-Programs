package com.Rohan;

/**
 * Created by Rohan on 12/16/2016.
 */
public class Car {

    private int doors;
    private int wheels;
    private String model;
    private String color;
    private String engine;

    public void setModel(String model ){
        String validModel = model.toLowerCase();
        if (validModel.equals("porsche carrera") || validModel.equals("ferrari f1")){
            this.model = model;
        }else{
            this.model = "Unknown";
        }
    }


    public String getModel(){
        return this.model;
    }
}
