package com.Rohan;

/**
 * Created by Rohan on 12/16/2016.
 */

public class Account {
    private String number;
    private double balance;
    private String customerName;
    private String customerEmail;
    private String customerPhone;

//    public double postdepositBalance;
//    public double savingsbalance;
//    public int prewithdrawalbalance;
//    public int postwithdrawalBalance;

    public Account(String customerName, String customerEmail, String customerPhone) {
        this("400", 600,customerEmail,customerName,customerPhone);
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.customerPhone = customerPhone;
    }

    public Account(){

        this("5000", 3000, "rpurohit01@yahoo.com", "Bruce", "2022152482");
        System.out.println("Default constructor called");
    }

    public Account(String number, double balance, String customerEmail, String customerName, String customerPhone){ // constructor parametrized
        this.number = number;
        this.balance= balance;
        this.customerEmail= customerEmail;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public void deposit(double depositAmount){
        this.balance += depositAmount;
    }

    public void withdrawal(double withdrawal){
        if(balance-withdrawal <0){
            System.out.println("Only " + balance + "available, withdrawal not processed");
        }else{
            this.balance -=withdrawal;
            System.out.println("Withdrawal of " + withdrawal+ "completed. Remaining balance = " + balance);
        }
    }

//My method needs some revision
//    public double depositMoney(int deposit) {
//        this.savingsbalance = postdepositBalance;
//        this.postdepositBalance = savingsbalance + deposit;
//        System.out.println("The account balance of " + savingsbalance + " has been deposited with $ " + deposit);
//        System.out.println("The new account balance is " + postdepositBalance);
//        return postdepositBalance;
//    }
//
//    public void withdrawal(double withdrawal) {
//       // this.savingsbalance = postdepositBalance;
//        if (savingsbalance - withdrawal <= 0) {
//            System.out.println("Only " + savingsbalance + "available, withdrawal not processed");
//        } else {
//            this.savingsbalance -= withdrawal;
//            System.out.println("Withdrawal of " + withdrawal + "completed. Remaining balance = " + savingsbalance);
    }

