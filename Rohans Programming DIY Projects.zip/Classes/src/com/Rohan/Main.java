package com.Rohan;

public class Main  {

    public static void main(String[] args) {
//	// write your code here
//        Car porsche = new Car();
//        //porsche.setModel("porsche carrera");
//        porsche.setModel("porsche unkown");
//        System.out.println("Model is "+ porsche.getModel());

       // Account Account1 = new Account();
       Account Account1 = new Account("101", 0, "rpurohit01@gmail.com", "Rohan", "2022152482");
        System.out.println("Account Constructor with parameters called");
        System.out.println("Account Holders Name " + Account1.getCustomerName());
//        Account1.setCustomerName("Rohan");
//        Account1.setCustomerEmail("rpurohit01@gmail.com");
//        Account1.setBalance(0.00);


        Account1.deposit(1000);
//        Account1.deposit(1000);
//        Account1.deposit(1000);
//        Account1.deposit(3000);

       // System.out.println(savingsbalance);
        Account1.withdrawal(1000);
//        Account1.withdrawal(850);
//        Account1.withdrawal(50);
//        Account1.withdrawal(100);
//
//        Account Account2 = new Account ("Bushi ", "bushi@gmail.com","5678");
//        System.out.println("New constructor called");
//        System.out.println(Account2.getNumber());
//        System.out.println(Account2.getBalance());
//        System.out.println( Account2.getCustomerName());
//        System.out.println(Account2.getCustomerEmail());
//
//        VIPCustomer Account3 = new VIPCustomer();
//        System.out.println(Account3.getName());
//        System.out.println(Account3.getEmail());
//        System.out.println(Account3.getCreditLimit());
//
//
//        VIPCustomer Account4=  new VIPCustomer("rpurohit01@gmail.com", 10000);
//        System.out.println(Account4.getName());
//        System.out.println(Account4.getEmail());
//        System.out.println(Account4.getCreditLimit());
//
//        VIPCustomer Account5 = new VIPCustomer("Rohan", "rpurohit01@yahoo.com", 10000);
//        System.out.println(Account5.getName());
//        System.out.println(Account5.getEmail());
//        System.out.println(Account5.getCreditLimit());
//
//




    }
}
