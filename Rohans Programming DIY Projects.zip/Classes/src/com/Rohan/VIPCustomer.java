package com.Rohan;

/**
 * Created by Rohan on 12/18/2016.
 */
public class VIPCustomer {

    public String name;
    public String email;
    public double creditLimit;



    public VIPCustomer(String name, String email, double creditLimit) {
        this.name = name;
        this.email = email;
        this.creditLimit = creditLimit;
        System.out.println("Parametrized constructor invoked");
    }

    public VIPCustomer( String email, double creditLimit){
        this("Rohan", email, creditLimit);
        System.out.println("Default name picked, provide email credit Limit parameters");
    }

    public VIPCustomer(){
        this("Bruce", "bushi@gmail.com", 1000);
        System.out.println("Default Constructor Called");
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public double getCreditLimit() {
        return creditLimit;
    }
}
