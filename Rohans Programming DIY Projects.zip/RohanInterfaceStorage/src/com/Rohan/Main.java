package com.Rohan;

public class Main {

    public static void main(String[] args) {

        IStorage sandisk;
        sandisk = new HardDisk();
        sandisk.storeContent("1", "iphone", "hat", "headphones");
        sandisk.retrieveContent("1");
        sandisk.storeContent("2", "ps4", "watch", "headphones");
        sandisk.retrieveContent("2");
        //sandisk.retrieveContent("1");


	// write your code here
    }
}
