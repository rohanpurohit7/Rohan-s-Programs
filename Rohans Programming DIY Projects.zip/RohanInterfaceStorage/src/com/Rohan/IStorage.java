package com.Rohan;

import java.util.LinkedList;

/**
 * Created by Rohan on 12/28/2016.
 */
public interface IStorage {

    LinkedList<String> storeContent(String id, String content1, String content2, String content3);
    LinkedList<String> retrieveContent(String id);

}
