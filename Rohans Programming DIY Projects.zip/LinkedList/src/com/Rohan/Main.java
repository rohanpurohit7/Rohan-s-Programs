package com.Rohan;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here

Customer customer = new Customer("Rohan", 200.00);
        Customer anotherCustomer;
        anotherCustomer= customer;
        anotherCustomer.setBalance(300.00); // the balance is set for customer object instead of anothercustomer.
        System.out.println("Balance for custoemr" + customer.getName() + "is " + customer.getBalance());

        ArrayList<Integer> intList = new ArrayList<Integer>();

        intList.add(1);
        intList.add(3);
        intList.add(4);

        for(int i =0; i<intList.size();i++){
            System.out.println(i + ":" + intList.get(i));
        }

        intList.add(1,2);

        for(int i =0; i<intList.size();i++){
            System.out.println(i + ":" + intList.get(i));
        }

    }
}
