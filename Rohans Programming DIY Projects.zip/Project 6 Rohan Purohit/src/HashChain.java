/** Hash table implementation using chains
 *  @author Torczon, Noonan, Dutton
 * */

public class HashChain <K, V> implements KWHashMap<K, V> {

    // Data Fields
    private static final int CAPACITY = 13;    // default initial table size

    //maximum allowable load factor
    private static final double LOAD_THRESHOLD = 1.0;

    private Entry<K,V>[ ] table;      // hash table
    
    private int numKeys;    // number of keys in the hash table

    /** Contains key-value pairs for a hash table,
        along with pointer to the
        next entry in the chain
        (or null, if at the end of a chain). */
    private static class Entry <K, V> {

        /** The key */
        private K key;
        /** The next entry */
        private Entry<K,V> next;
        /** The value */
        private V value;

        /** Creates a new key-next-value triplet.
            @param key The key
            @param next The next index
            @param value The value
        */
        public Entry(K key, Entry<K,V> next, V value) {
            this.key = key;
            this.next = next;
            this.value = value;
        } // end Entry(key, next, value)

	/** Retrieves the key.
	    @return The key
	*/
	public K getKey() {
	    return key;
	}//end getKey()

	/** Retrieves the value.
	    @return The value
	*/
	public V getValue() {
	    return value;
	}//end getValue()

	/** Sets the value.
	    @param val The new value
	    @return The old value
	*/
	public V setValue(V val) {
	    V oldVal = value;
	    value = val;
	    return oldVal;
	}//setValue(val)

    } // end class Entry

    /** Initialize the hashtable
     */
    public HashChain() {
        this(CAPACITY);
    } // end HashChain()

    
    /** Initialize the hashtable
     */
    public HashChain(int capacity) {
    	//
    	table = new Entry[capacity];

        // Implementation left as a project.

    } // end HashChain()

    
    /** Method get for class HashChain.
        @param key The key being sought
        @return the value associated with this key if found;
        otherwise, null
    */
    public V get(Object key) {
      int index = key.hashCode()%table.length;
      if(index<0)
    	  index += table.length;
      if(table[index] == null)
    	  return null;// key is not in the table.
      
      //Search the list at table[index] to find the key.
      Entry nextItem = table[index];
  	while(nextItem!=null){
      //for(Entry<K, V> nextItem : table[index]){
    	  if(nextItem.key.equals(key))
    		  return (V) nextItem.value;
    	  nextItem = nextItem.next;
      }
    	// assert: key is not in the table.
      return null;
        
      // Implementation left as a project.

    } // end get(key)

    /** Method put for class HashChain.
        post: This key-value pair is inserted at the head of the appropriate
              bucket in the table and numKeys is incremented. If the 
              key is already in the table, its value is changed to the 
              argument value and numKeys is not changed.
        @param key The key of item being inserted
        @param value The value for this key
        @return Old value associated with this key if found;
        otherwise, null
    */
    public V put(K key, V value) {
    	// Find the first table element that is empty
    	// or the table element that contains the key.
    	int index = key.hashCode()% table.length;
    	if(index <0)
    		index += table.length;
    	if(table[index] == null){
        table[index] = new Entry(key, null, value);
    	}
    	//Search the list at table[index] to find the key.
    	 Entry nextItem = table[index];
    	  	while(nextItem!=null){
    		//If the search is successfull, replace the old value.
    		if(nextItem.key.equals(key)){
    			//Replace value for this key.
    			V oldVal = (V) nextItem.value;
    			nextItem.setValue(value);
    			return oldVal;
    		}
    		nextItem = nextItem.next;
    	}
   	
    	numKeys++;
    	if(numKeys>(LOAD_THRESHOLD * table.length))
    		rehash();
    	return null;
        // Implementation left as a project.

    } // end put(key, value)

    /** Method remove for class HashChain
       post: This entry with this key is removed from the table
       if present and numKeys is decremented. If the key is not
       present, nothing is removed.
       @param  key The key of the item to be removed.
       @return Removed value associated with this key if found;
               otherwise, null.
    */
    public V remove(Object key){
    	int index = key.hashCode()% table.length;
    	if(index <0)
    		index += table.length;
    	if(table[index] == null){
    		return null;// key is not in the table.
    	}
    	//Search the list at table[index] to find the key.
    	//for(Entry<K,V> nextItem : table[index]){
    	Entry nextItem = table[index];
    	Entry previous = nextItem;
    	V oldVal = null;
    	while(nextItem!=null){
    		//If the search is successfull, remove the entry with this key and decrement numKeys.
    		if(nextItem.key.equals(key)){
    			previous.next = nextItem.next;
    			 oldVal = (V) nextItem.value;
    		}
    		previous = nextItem;
    		nextItem = nextItem.next;
    	}
    	numKeys--;
		return oldVal;
        //Implementation left as a project

    }//end remove(key)

    // Returns the number of entries in the table.
    public int size() {
    return numKeys;
        // Implementation left as a project.
    
    } // end size()
    
    // Returns true if this table contains no key-value mappings.
    public boolean isEmpty() {
    	return numKeys == 0;

        // Implementation left as a project.
         
    } // end isEmpty()

    public String toString() {
    	String toreturn = "";
    	for(int i = 0;i<table.length;i++){
    		if(table[i]!= null){
    		toreturn += i +" ⇒ ";
    		Entry next = table[i];
    		while(next!= null){
    			toreturn += next.value +"; ";
    		next = next.next;	
    		}
    		toreturn+= "\n";
    		}
    	}
    	return toreturn;

        // Implementation left as a project.
    
    } // end toString()

    /** Method rehash for class HashChain
     * post: the Hashtable is approximately doubled in capacity
     * and the elements are moved to the new table
     */
    private void rehash(){
    	
    	Entry<K,V>[] oldTable = table;//Save a reference to oldTable.
    	int size = nextLargestPrime(2 * oldTable.length +1);
    	table = new Entry[size];// Double capacity of this table.
    	
    	// Reinsert all items in oldTable into expanded table.
    	numKeys = 0;
    	
    	for(int i = 0;i<oldTable.length;i++){
    		if((oldTable[i] != null) && (oldTable[i] != null)){
    			// Insert an entry in expanded table
    			put(oldTable[i].key, oldTable[i].value);
    	
    			}
    	
    	
    	
    	}
    }
        
        //Implementation left as project
        
        //When "doubling" the capacity of the table, create the new table
        //capacity to be the next prime number greater than 2*b, where b is the
        //current number of buckets in the table.

    //end rehash()

    protected int nextLargestPrime(int n){
        //This method will determine what the next largest prime number is 
        //that is greater than n.

        //Note: you do NOT need to worry about issues such as overflow, i.e. 
        //reaching an integer that is larger than "int" can hold. You may
        //also assume n will be greater than 1.
        
    	int result = n;
         result++;
         while(!isPrime(result)){
        	 result++;
         }//end while
         return result;
         }

    protected boolean isPrime(int n){
        //Method to determine if an integer n is a prime number.
        //
        //Note: again you may assume n will be greater than 1.
   int p;
   for(p = 2; p<n; p++){
	   if(n % p == 0){
		   return false;
	   }
	   }
return true;
   }
    	 
    
    

} // end class HashChain
