
public class TestProj6 {
	public static void main(String[]args){
		HashChain a = new HashChain();// initiate new Hash Table.
		System.out.println("---Initiating and printing original Hash Table---");
		a.put(0, 'j');
		a.put(1, 'a');
		a.put(2, 'v');
		a.put(3, 'a');// addition of elements to test the data structure.
		
		System.out.println(a.toString());// Testing to String method\
		
		System.out.println("---Printing the modified Hash Table---");
		a.remove(2);
		a.put(2, 'd');
		a.remove(3);
		a.put(3, 'e');
		
		System.out.println(a.toString());// testing the put method and the remove method.
		
	
		System.out.println("The put and remove methods work.");
		
	if(a.get(1).equals('a'))
			System.out.println("The get method works.");// testing get method.
	
	HashChain b = new HashChain();// initiate a new Hash Table named b also tests constructor.
	b.put(0,'j');
	b.put(1, 'a');
	b.put(2, 'v');
	b.put(3, 'a');// addition of elements to test the data structure.
	
	System.out.println(b.size());
	System.out.println(b.isEmpty());
	
	System.out.println(a.isPrime(4));// tests if 4 is prime
	System.out.println(a.isPrime(7));// tests if 7 is prime.
	System.out.println(a.nextLargestPrime(10));// prints out next largest prime after 10.
	System.out.println(a.nextLargestPrime(20));//prints out the next largest prime after 20.
	
	}
}// end Test Proj 6
