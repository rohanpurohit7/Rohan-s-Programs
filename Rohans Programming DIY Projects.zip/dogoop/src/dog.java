
public class dog {
	private int size;// instance variable is private
	String breed;
	String name;
	
	public int getSize(){// getter and setters are public
		return size;
	}
	
	public void setSize(int s){
		size = s;
	}
	
	void bark() {
		if(size >60){
			System.out.println("Woof! Woof!");
		}else if(size >14){
			System.out.println("Ruff! Ruff!");
		}else {
			System.out.println("Yip! Yip!");
		}
		
		/*void bark(int numOfBarks){
			while(numOfBarks >0){
				System.out.println("ruff");
				numOfBarks = numOfBarks-1;
			}*/
		
		}
	}

