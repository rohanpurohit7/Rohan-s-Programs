
public class dogtester {

public static void main(String[] args){
	dog d = new dog();
	d.setSize(23);
	d.bark();
	System.out.println(d.getSize());
	//System.out.println(d.size);
	dog e = new dog();
	e.setSize(80);
	e.bark();
	System.out.println(e.getSize());
	dog f  = new dog();
	f.setSize(2);
	f.bark();
	System.out.println(f.getSize());
	
	
}
}
