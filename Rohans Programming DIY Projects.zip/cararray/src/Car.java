
public class Car {
	String name;
	String position;
	public static void main (String[] args){
		
		
		
		// make garage array
		Car[] garage = new Car[3];
		// populate the garage
		garage[0] =  new Car();
		garage[1] =  new Car();
		garage[2]= new Car();
		
		
		// identify remaining cars using array references
		garage[0].name = "Nissan";
		garage[1].name = "Chevy";
		garage[2].name = "Ford";
		garage[0].position = "1";
		garage[1].position = "2";
		garage[2].position = "3";
		
		// print invocation
		
		System.out.println("The garage can house " +garage.length+ " cars.");
		for(int y =0; y<garage.length; y++){
		System.out.println("the car in garage slot "+garage[y].position+ " is " + garage[y].name);
		

		}
		
		//loop through the garage and do a horn check
		int x = 0;
		while(x < garage.length){
			garage[x].testdrive();
			x++;
		}
	}
	public void testdrive(){
		System.out.println(name + "'s horn sounds 'beep beep'");
	}
	
}