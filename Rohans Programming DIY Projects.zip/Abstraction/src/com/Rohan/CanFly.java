package com.Rohan;

/**
 * Created by Rohan on 1/3/2017.
 */
public interface CanFly {

    void fly();


}
