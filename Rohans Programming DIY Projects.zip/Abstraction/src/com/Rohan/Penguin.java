package com.Rohan;

/**
 * Created by Rohan on 1/3/2017.
 */
public class Penguin extends Bird {
    public Penguin(String name) {
        super(name);
    }

    @Override
    public void fly() {
        System.out.println("Cant fly");
    }
}
