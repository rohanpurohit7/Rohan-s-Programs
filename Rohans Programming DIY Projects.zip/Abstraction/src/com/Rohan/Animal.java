package com.Rohan;

/**
 * Created by Rohan on 1/3/2017.
 */
public abstract class Animal {
    private String name;

    public Animal(String name) {
        this.name = name;
    }


    public abstract void eat();
    public abstract void breathe();

    public String getName() {
        return name;
    }
}
