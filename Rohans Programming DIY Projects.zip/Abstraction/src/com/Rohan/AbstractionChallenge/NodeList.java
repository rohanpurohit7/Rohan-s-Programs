package com.Rohan.AbstractionChallenge;

/**
 * Created by Rohan on 1/3/2017.
 */
public interface NodeList {
    ListItem getRoot();
    boolean addItem(ListItem item);
    boolean removeItem(ListItem item);
    void traverse(ListItem root);
}
