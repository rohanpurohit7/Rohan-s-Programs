package com.Rohan.AbstractionChallenge;

/**
 * Created by Rohan on 1/3/2017.
 */
public class MyLinkedList implements NodeList {
    private ListItem root = null;

    public MyLinkedList(ListItem root) {
        this.root = root;
    }


    @Override
    public ListItem getRoot() {
        return this.root;
    }

    @Override
    public boolean addItem(ListItem newitem) {
        if (this.root == null) {
            // if list was empty this item becomes head of list
            this.root = newitem;
            return true;
        }
        ListItem currentItem = this.root;
        while (currentItem != null) {
            int comparison = (currentItem.compareTo(newitem));
            if (comparison < 0) {
                // new item is greater, move right if possible
                if (currentItem.next() != null) {
                    currentItem = currentItem.next();
                } else {
                    // there is no next insert at end of list
                    currentItem.setNext(newitem);
                    newitem.setPrevious(currentItem);
                    return true;
                }
            } else if (comparison > 0) {
                //newitem is less, insert before
                if (currentItem.previous() != null) {
                    currentItem.previous().setNext(newitem);
                    newitem.setPrevious(currentItem.previous());
                    newitem.setNext(currentItem);
                    currentItem.setPrevious(newitem);
                } else {
                    //node with a previous is root
                    newitem.setNext(this.root);
                    this.root.setPrevious(newitem);
                    this.root = newitem;
                }
                return true;
            } else {
                //equal
                System.out.println(newitem.getValue() + " is already present, not added");
                return false;
            }
        }
        return false;
    }


    @Override
    public boolean removeItem(ListItem item) {
        if (item != null) {
            System.out.println("Removing item" + item.getValue());
        }
        ListItem currentItem = this.root;
        while (currentItem != null) {
            int comparison = currentItem.compareTo(item);
            if (comparison == 0) {
                //found the item to delete
                if (currentItem == this.root) {
                    this.root = currentItem.next();
                } else {
                    currentItem.previous().setNext(currentItem.next());
                    if (currentItem.next() != null) {
                        currentItem.next().setPrevious(currentItem.previous());
                    }
                }
                return true;
            } else if (comparison < 0) {
                currentItem = currentItem.next();
            } else {
                return false;
            }
        }
        return false;
    }

        @Override
        public void traverse (ListItem root){
            if (root == null) {
                System.out.println("The list is empty");
            } else {
                while (root != null) {
                    System.out.println("root is " + root.getValue());
                    root = root.next();
                }

            }
        }
    }
