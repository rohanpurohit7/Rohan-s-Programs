package com.Rohan.AbstractionChallenge;

/**
 * Created by Rohan on 1/3/2017.
 */
public class Main {





    public static void main(String[] args) {

//        MyLinkedList list = new MyLinkedList(null);
//        list.traverse(list.getRoot());

        SearchTree mytree = new SearchTree(null);
        mytree.traverse(mytree.getRoot());



        String stringData = " 9 8 5 7 6 4 3 2 1 0";
        String [] data = stringData.split(" ");
        for( String s: data){
            mytree.addItem(new Node(s));
    }
    mytree.traverse(mytree.getRoot());
}}


