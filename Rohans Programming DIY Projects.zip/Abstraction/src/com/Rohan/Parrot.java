package com.Rohan;

/**
 * Created by Rohan on 1/3/2017.
 */
public class Parrot extends Bird {

    public Parrot(String name) {
        super(name);
    }


}
