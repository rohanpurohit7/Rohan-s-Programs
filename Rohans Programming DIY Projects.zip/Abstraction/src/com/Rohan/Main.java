package com.Rohan;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Dog dog = new Dog("Bruce");
        dog.getName();
        dog.eat();
        dog.breathe();

        Parrot bird = new Parrot("Parrot");
        bird.getName();
        bird.eat();
        bird.breathe();
        bird.fly();

        Penguin penguin = new Penguin("pingu");
        penguin.fly();
    }
}
