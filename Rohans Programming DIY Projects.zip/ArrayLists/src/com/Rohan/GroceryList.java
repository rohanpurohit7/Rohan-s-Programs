package com.Rohan;

import java.util.ArrayList;

/**
 * Created by Rohan on 12/21/2016.
 */
public class GroceryList {

    private ArrayList<String> groceryList = new ArrayList<>();

    public ArrayList<String> getGroceryList() {
        return groceryList;
    }

    public void addGroceryItem(String item) {
        groceryList.add(item);
    }

    public void printGroceryList() {
        System.out.println("You have " + groceryList.size() + " items in your grocery list.");
        for (int i = 0; i < groceryList.size(); i++) {
            System.out.println((i + 1) + ". " + groceryList.get(i));
        }
    }

    public void modifyGroceryItem(String currentItem,String newItem) { // overloaded method
        int position = findItem(currentItem);
        if (position >= 0) {
            modifyGroceryItem(position, newItem);
            System.out.println("Modified old item" + currentItem+ "set " + newItem + " at position " + (position + 1));

        }
    }

    private void modifyGroceryItem(int position, String newItem) {
        groceryList.set(position, newItem);
    }

    public void removeGroceryItem(String item) { // overloaded method
        int position = findItem(item);
        if (position >= 0) {
            removeGroceryItem(position);
            System.out.println(item + " was removed from the list.");
        }
    }

    private void removeGroceryItem(int position) {
        groceryList.remove(position);
    }

    private int findItem(String searchItem) {
//        boolean exists = groceryList.contains(searchItem);
//       int position = groceryList.indexOf(searchItem);
//        if(position >=0){
////           return groceryList.get(position);
////       }
////       return null;
        return groceryList.indexOf(searchItem);}

        public boolean onFile(String searchItem){
            int position =findItem(searchItem);
            if (position<0){
                return false;
            }else{
                return true;
            }
    }
//
    }



