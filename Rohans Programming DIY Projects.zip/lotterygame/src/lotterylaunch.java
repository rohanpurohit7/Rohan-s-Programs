
public class lotterylaunch {
public static void main(String[] args){
	lotterygame game = new lotterygame();
	game.startGame();
}
}
