
public class lotterygame {
Player p1;
Player p2;
Player p3;

public void startGame(){
	p1 = new Player();
	p2 = new Player();
	p3 = new Player();
	
	int ticketp1 = 0;
	int ticketp2 = 0;
	int ticketp3 = 0;
	
	boolean p1isRight = false;
	boolean p2isRight = false;
	boolean p3isRight = false;
	
	int targetNumber = (int) (Math.random() *10);
	System.out.println("The winning lottery ticket number is between 1 and 9, lets draw it out of the mixer");
	
	while(true){
		System.out.println("The ticket number we have drawn out is.." + targetNumber);
		
		p1.draw();
		p2.draw();
		p3.draw();
		
		ticketp1 = p1.number;
		System.out.println("Player one has ticket number " + ticketp1);
		
		ticketp2 = p2.number;
		System.out.println("Player two has ticket number " + ticketp2);
		
		ticketp3 = p3.number;
		System.out.println("Player three has ticket number " + ticketp3);
		
		if(ticketp1 == targetNumber){
			p1isRight= true;
		}
		if(ticketp2 == targetNumber){
			p2isRight = true;
		}
		if(ticketp3 == targetNumber){
			p3isRight = true;
		}
		if(p1isRight||p2isRight||p3isRight){
			System.out.println("We have a winner!");
			System.out.println("Did player1 guess the winning lottery ticket number? " + p1isRight);
			System.out.println("Did player2 guess the winning lottery ticket number? " + p2isRight);
			System.out.println("Did player3 guess the winning lottery ticket number? " + p3isRight);
			System.out.println("Game show is over.Thanks for watching");
			break;// game over break the loop.
		} else{
			//we must keep going until a winner emerges.
			System.out.println("Players will have to try again since no one drew the lucky ticket.");
		}// end if else
	}// end loop
}// end method
}// end class
		
			

