
public class Player {
	int number = 0; // ticket receptacle
	
	public void draw(){
		number = (int) (Math.random() *10);
		
	}

}
