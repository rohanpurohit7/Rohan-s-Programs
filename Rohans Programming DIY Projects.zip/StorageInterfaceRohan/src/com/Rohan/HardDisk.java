package com.Rohan;

import java.util.List;

/**
 * Created by Rohan on 12/28/2016.
 */
public class HardDisk implements IStorage {

    private String id;
    private String content1;
    private String content2;
    private String content3;
    List<String> retrievedContent;

    @Override
    public List<String> storeContent(String id, String content1, String content2, String content3) {
        retrievedContent.add(0, id);
        retrievedContent.add(1, content1);
        retrievedContent.add(2, content2);
        retrievedContent.add(3, content3);
        System.out.println("Now storing with id "+ id + retrievedContent.toString());
        return retrievedContent;
    }

    @Override
    public List<String> retrieveContent(String id) {
        if (id != retrievedContent.get(0)) {
            System.out.println("The content is not in stored media");
        } else {
            return retrievedContent;
        }
        return retrievedContent;
    }

    @Override
    public String toString() {
        return retrievedContent + " was stored in media";
    }
}

