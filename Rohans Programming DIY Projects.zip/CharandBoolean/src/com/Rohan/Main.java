package com.Rohan;

public class Main {

    public static void main(String[] args) {

	// write your code here
        char myChar = '\u00A9'; // width of 16 ( 2bytes)
        System.out.println("Unicode output was:" + myChar);

        boolean myBoolean = true;
        boolean isMale = true;

        //primitive types of data
        // byte
        //short
        //int
        // long
        //float
        //double
        //char
        //boolean


    }
}
