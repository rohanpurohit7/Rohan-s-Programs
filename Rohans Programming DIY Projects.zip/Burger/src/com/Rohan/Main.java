package com.Rohan;

public class Main {

    public static void main(String[] args) {

        HamBurger munchie = new HamBurger(1, 1, 1, 1, 2, "Classic");
        HealthyBurger crunchie = new HealthyBurger(1, 1, 1, 1, 1, "Wheat");
        DeluxeBurger tasty = new DeluxeBurger(0,0,1,1,1,"HerbsandCheese", true);




	// write your code here
    }
}
