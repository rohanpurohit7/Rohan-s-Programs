package com.Rohan;

/**
 * Created by Rohan on 12/20/2016.
 */
public class Burger {
    public String breadroll;
    public String meatType;
    public int tomatoes;
    public int pickles;
    public int lettuce;
    public int jalapenos;
    public int quantity;
    public double foodcost;
    public double optionsprice;
    public double baseprice;


    public Burger(int tomatoes, int pickles, int lettuce, int jalapenos, int quantity) {
        this.breadroll = breadroll;
        this.meatType = meatType;
        this.tomatoes = tomatoes;
        this.pickles = pickles;
        this.lettuce = lettuce;
        this.jalapenos = jalapenos;
        this.quantity = quantity;
    }

        public String getBreadroll() {
            return breadroll;
        }

        public String getMeatType() {
            return meatType;
        }

        public int getTomatoes() {
            return tomatoes;
        }

        public int getPickels() {
            return pickles;
        }

        public int getLettuce() {
            return lettuce;
        }

        public int getJalapenos() {
            return jalapenos;
        }

        public int getQuantity() {
            return quantity;
        }

    public double priceBurger(){
        foodcost = optionsprice(tomatoes,pickles, lettuce, jalapenos) + baseprice(quantity);
        return foodcost;
    }

    public double optionsprice(int tomatoes, int pickles, int lettuce, int jalapenos ){

        optionsprice = (((tomatoes * (2)  ) + (pickles *(3)) +( lettuce * (4)) + (jalapenos * (5))));
        return optionsprice;
    }

    public double baseprice(int quantity){
        baseprice = (quantity * 5);
        return baseprice;
    }


}

