package com.Rohan;

/**
 * Created by Rohan on 12/20/2016.
 */
public class HealthyBurger extends Burger{
    public String breadroll;
    public String meatType;
    public int tomatoes;
    public int pickles;
    public int lettuce;
    public int jalapenos;
    public int quantity;
    public double foodcost;
    public double optionsprice;
    public double baseprice;

    public HealthyBurger(int tomatoes, int pickles, int lettuce, int jalapenos, int quantity, String breadroll) {
        super(tomatoes, pickles, lettuce, jalapenos, quantity);
        this.breadroll = breadroll;
        this.meatType = "Vegetarian";

        System.out.println("Building " + quantity+" "+ getClass().getSimpleName()+" burger with " + tomatoes +" tomatoes," + pickles +" pickels," + lettuce +" lettuce, " );
        System.out.println("Your food cost is $" + priceBurger());
    }

    @Override
    public double priceBurger() {
        return super.priceBurger();
    }

    @Override
    public double optionsprice(int tomatoes, int pickles, int lettuce, int jalapenos) {
        return super.optionsprice(tomatoes, pickles, lettuce, jalapenos);
    }

    @Override
    public double baseprice(int quantity) {
        return super.baseprice(quantity);
    }

    public String getBreadroll() {
        return breadroll;
    }

    public String getMeatType() {
        return meatType;
    }

    public int isTomatoes() {
        return tomatoes;
    }

    public int isPickles() {
        return pickles;
    }

    public int isLettuce() {
        return lettuce;
    }

    public int isJalapenos() {
        return jalapenos;
    }


}
