package com.Rohan;

/**
 * Created by Rohan on 12/20/2016.
 */
public class DeluxeBurger extends Burger {
    public String breadroll;
    public String meatType;
    public int tomatoes;
    public int pickles;
    public int lettuce;
    public int jalapenos;
     public int quantity;
    public double foodcost;
    public double optionsprice;
   public double baseprice;
    public boolean sides;
    public String chips;
    public String drink;


    public DeluxeBurger(int tomatoes, int pickles, int lettuce, int jalapenos, int quantity, String breadroll,boolean sides ){
        super(tomatoes, pickles, lettuce, jalapenos, quantity);
        this.breadroll = breadroll;
        this.meatType = "Ham";
        this.sides= sides;

        System.out.println("Building " + quantity+" "+ getClass().getSimpleName()+" burger with " + tomatoes +" tomatoes," + pickles +" pickels," + lettuce +" lettuce, " );
        System.out.println("Your food cost is $" + priceBurger());
        freechipsandDrink(sides);

    }

    public void setChipsandDrink(String chips, String drink){
        this.chips = chips;
        this.drink = drink;
         }

    public String getChips() {
        return chips;
    }

    public String getDrink() {
        return drink;
    }

    public void freechipsandDrink(boolean sides) {
        double bonusAmount = 20.00 - priceBurger();
        if ((sides == true) && (priceBurger() >= 20)) {
            setChipsandDrink("Doritos", "Pepsi");
            System.out.println("You get a free side of  Doritos and Pepsi.");
        }else if (sides == false){
            System.out.println("You did not pick a side option");
        }
        else if((sides == true) && (priceBurger() <20)){
                  System.out.println("Please buy items of at least $"+ bonusAmount+ "more to get the complementary chips and drink");        }
       }

    @Override
    public double priceBurger() {
        return super.priceBurger();
    }

    @Override
    public double optionsprice(int tomatoes, int pickles, int lettuce, int jalapenos) {
        return super.optionsprice(tomatoes, pickles, lettuce, jalapenos);
    }

    @Override
    public double baseprice(int quantity) {
        return super.baseprice(quantity);
    }

    public String getBreadroll() {
        return breadroll;
    }

    public String getMeatType() {
        return meatType;
    }

    public int isTomatoes() {
        return tomatoes;
    }

    public int isPickles() {
        return pickles;
    }

    public int isLettuce() {
        return lettuce;
    }

    public int isJalapenos() {
        return jalapenos;
    }


}
