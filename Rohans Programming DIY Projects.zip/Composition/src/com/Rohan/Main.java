package com.Rohan;

public class Main {

    public static void main(String[] args) {

//        Dimension dimension = new Dimension(27, 10, 5);
//        Case rpc = new Case("HP-Desktop", "HP","wired",dimension);
//       // Resolution resolution = new Resolution(1080, 1080);
//        Monitor monitor = new Monitor("Flatscreen", "HP", 27, new Resolution(1080, 1080));
//        Motherboard motherboard = new Motherboard("Intel-i-7", "Intel", 16, 5, "WindowsBIOS");
//
//        PC hp = new PC(rpc, monitor,motherboard );
//        hp.powerUp();
	// write your code here

        Table oak = new Table("Large", "red", "oak");
        Room room = new Room(1000,"LivingRoom",oak,new Sofa("leather",3));
        oak.setTable();
        room.getDiningTable();
        //room.getDiningTable();


    }
}
