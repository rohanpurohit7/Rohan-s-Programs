package com.Rohan;

/**
 * Created by Rohan on 12/28/2016.
 */
public interface ITelephone {

     void powerOn();
     void dial(int phonenumber);
     void answer();
     boolean callPhone(int phonenumber);
     boolean isRinging();
}
