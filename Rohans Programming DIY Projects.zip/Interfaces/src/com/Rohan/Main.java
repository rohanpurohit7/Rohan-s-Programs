package com.Rohan;

public class Main {

    public static void main(String[] args) {

        ITelephone rohansPhone;
//        rohansPhone = new DeskPhone(123);
//        rohansPhone.callPhone(321);
//        System.out.println(rohansPhone.isRinging());
//        rohansPhone.answer();

        rohansPhone = new MobilePhone(123);
        rohansPhone.powerOn();
        rohansPhone.callPhone(123);
        rohansPhone.answer();


        }

    }

