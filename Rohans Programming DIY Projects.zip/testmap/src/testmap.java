import java.util.*;

public class testmap {
	public static void main(String[] args){
		HashMap<String,Integer> stuff = new HashMap<String,Integer>();
		stuff.put("R", 7);
		stuff.put("P", 89);
		stuff.put("String", 50);
		stuff.put("String", 56);
		System.out.println("This HashMap prints out key value pairs , you cant have duplicate keys.");
		System.out.println(stuff);
		System.out.println(stuff.get("R"));
	}

}
